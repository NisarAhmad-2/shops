<?php 
require("connection.php");
require("menu.php");
$datefrom = $_POST['datefrom'];
$dateto = $_POST['dateto'];
if(isset($_POST['supplieraccount'])){
$acc = $_POST['supplieraccount'];
$accex = explode('|',$acc);
$ac_code = $accex[0];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>SHOPS</title>
	<style>
	@media print{
	.noprint {
	visibility:hidden;
	}
	}
	</style>
    <style type="text/css">
<!--
.style8 {font-weight: bold; color: #FF0000; font-size: x-large; }
.style11 {
	color: #FF0000;
	font-weight: bold;
	font-size: large;
}
.style12 {color: #0000FF}
.style14 {color: #0000FF; font-weight: bold; }
-->
    </style>
</head>
<body>


<form action=""  method="post">
<table width="833"  class="noprint" border="0">
  <tr>
  <td width="15%" align="left" valign="top"><div align="center"><strong><span class="style12"> Account<br>
      <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
        <?php
$sql = "SELECT * FROM accountsnames WHERE headscode <> 7";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" <?php if($row['code']==$ac_code) echo " selected "; ?>><?php echo $row['name']; ?></option>
         <?php
}
} ?>
        </select>
    </span>
  </strong></div>
  <td width="10%" align="center" valign="bottom">
    <div align="center"></div>
  <td width="31%" align="left" valign="top"><div align="center"><strong><span class="style12">Date from <br>
    <input name="datefrom" type="date" id="datefrom"  value="<?php echo date("Y-m-d");?>">
    
    
    
    </span>
  </strong></div>
  <td width="29%" height="53" align="left" valign="bottom"><div align="center"><strong><span class="style12">Date to <br>
    <input name="dateto" type="date" id="dateto"  value="<?php echo date("Y-m-d");?>">
  </span></strong></div></td>
    <td width="15%" height="53" align="left" valign="bottom"><div align="center"><strong>
      <input name="search" type="submit" id="search" value="search" />
    </strong></div></td>
  </tr>
</table>
<div class="container" class="noprint" align="center">
      <p>&nbsp;</p>
 <div align="center" class="style14">
      <button class="noprint" class="style14"  onClick="window.print()"> Print</button>
</div>
</form>
	
<p>&nbsp;</p>
</form>
  <table width="1103" height="83"  class="table table-bordered">
    <thead>
      <tr>
        <th width="150"><span class="style14">Voucher No</span></th>
        <th width="145"><span class="style14">Invoice No</span></th>
        <th width="145"><span class="style14">Date</span></th>
        <th width="155"><span class="style14">Account Name</span></th>
        <th width="116"><span class="style14">Debit</span></th>
        <th width="104"><span class="style14">Credit</span></th>
        <th width="118"><span class="style14">Remarks</span></th>
        <th width="118"><span class="style14">Entry Type</span></th>
      </tr>
    </thead>
    <tbody>
      <?php 
if(!empty($_POST['supplieraccount'])){
$sql = "SELECT * FROM accountsledger WHERE supplieraccountcode = '$ac_code' 
and date between '$datefrom' and '$dateto'";
$result = $con->query($sql);
}
if(!empty($_POST['supplieraccount'])){
$sql = "SELECT * FROM accountsledger WHERE supplieraccountcode = '$ac_code'";
$result = $con->query($sql);
}
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><span class="style14"><?php echo $row['voucherno']; ?></span></td>
        <td><span class="style14"><?php echo $row['invoiceno']; ?></span></td>
        <td><span class="style14"><?php echo $row['date'];?></span></td>
        <td><span class="style14"><?php echo $row['supplieraccountname']; ?></span></td>
        <td><span class="style14"><?php echo $row['debit']; ?></span></td>
        <td><span class="style14"><?php echo $row['credit']; ?></span></td>
        <td><span class="style14"><?php echo $row['remarks']; ?></span></td>
        <td><span class="style14"><?php echo $row['entrytype']; ?></span></td>
      </tr>
    </tbody>
<?php
$supplieraccountcode=$balance;
$tcredit = $tcredit+$row['credit'];
$tdebit = $tdebit+$row['debit']; 
$tbalance = $tdebit-$tcredit; 
$i = $i+1;
}//while loop.
  }
 else {
  echo "0 results";
}
 ?>
</table>
  <div align="center">
  <table width="1084"  border="0" >
    <tr>
      <td width="65%" height="28" align="right" valign="top">  <div align="right" class="style8">Total  = <?php echo $tdebit; ?> </div></td>
      <td width="11%" align="right" valign="top"><div align="center"><span class="style8"><?php echo $tcredit; ?></span></div></td>
      <td width="24%" align="right" valign="top">
	  <div align="center" class="style11">          
	    <div align="right">BALANCE=<?php echo $tbalance; ?>		  </div>
	  </div>	  </td>
  </table>
</div>
</body>

</html>