<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$name = $_POST['name'];
	$purchaserate = $_POST['purchaserate'];
	$salerate = $_POST['salerate'];
	$margin = $_POST['margin'];
	
	

$sql = "INSERT INTO itemnames ( code,name,purchaserate,salerate,margin)
VALUES ( '$code','$name','$purchaserate','$salerate','$margin')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:item.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>