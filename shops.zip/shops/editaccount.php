<?php 
require("connection.php");
if(isset($_POST['save'])){
$id = $_GET['id'];
$code = $_POST['code'];
	$voucherno = $_POST['voucherno'];
	$date = $_POST['date'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$headsname = $_POST['headsname'];
	$headsname = explode('|',$headsname);
	$headscode = $headsname[0];
	$headsname = $headsname[1];
	$debit=$openingdr = $_POST['openingdr'];
	$credit=$openingcr = $_POST['openingcr'];
	
$sql = "UPDATE accountsnames SET
      voucherno = '$voucherno',
		date = '$date', 
		name = '$name',
		address = '$address',
		contact = '$contact',
		headsname = '$headsname',
		openingdr = '$openingdr',
		openingcr = '$openingcr'
		WHERE id = '$id'";

if ($con->query($sql) === TRUE) {
//header("location:account.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
$sql = "UPDATE accountsledger SET
        voucherno = '$voucherno',
		date = '$date', 
		supplieraccountname = '$supplieraccountnames',
		headsname = '$headsname',
		debit = '$debit',
		credit = '$credit'
		WHERE voucherno = '$voucherno'";

if ($con->query($sql) === TRUE) {
header("location:account.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$id = $_GET['id'];
$sql = "SELECT * FROM accountsnames WHERE id = '$id'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>
<style type="text/css">
<!--
.style4 {color: #FF0000; font-weight: bold; }
.style5 {color: #0000FF; font-weight: bold; }
-->
</style>


<form action="?id=<?php echo $id; ?>" method="post">
<table width="104%" height="112"  border="0" align="center">
  <tr>
    <td width="18%" height="40" align="left" valign="top"><div align="center" class="style5">
      <div align="center">Code<br>
        <input name="code" type="text" id="code"value="<?php echo $row['code']; ?>" readonly="readonly">
        </div>
    </div></td>
	<td width="17%" height="40" align="left" valign="top"><div align="center" class="style5">
      <div align="center">Voucherno<br>
        <input name="voucherno" type="text" id="voucherno"value="<?php echo $row['voucherno']; ?>" readonly="readonly">
        </div>
    </div></td>
	<td width="18%" align="left" valign="top"><div align="center" class="style5">
      <div align="center">Date<br>
        <input name="date" type="text" id="date" value="<?php echo $row['date']; ?>">
        </div>
    </div></td>
    <td width="19%" align="left" valign="top"><div align="center" class="style5">
      <div align="center">Name<br>
        <input name="name" type="text" id="name" value="<?php echo $row['name']; ?>">
        </div>
    </div></td>
	<td width="16%" height="40" align="left" valign="top"><div align="center" class="style5">
	  <div align="center">Address<br>
	    <input name="address" type="text" id="address" value="<?php echo $row['address']; ?>">
        </div>
	</div></td>
	<td width="6%" height="40" align="left" valign="top"><div align="center" class="style5">
	  <div align="center"></div>
	</div></td>
	<td width="6%" height="40" align="left" valign="top"><div align="center" class="style5">
	  <div align="center"></div>
	</div></td>
	
  <tr>
    <td height="29" align="left" valign="top"><div align="center" class="style5">
      <div align="center">Contact<br />
        <input name="contact" type="text" id="contact" value="<?php echo $row['contact']; ?>" />
      </div>
    </div>
	<td width="17%" height="30" align="left" valign="top" class="style5"><div align="center">Heads Names <br/>
        <select name="headsname" id="headsname">
          <?php
$sql = "SELECT * FROM headsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row2['code']."|".$row2['name']; ?>" <?php if($row['headscode']==$row2['code']) echo ' selected="selected"'; ?>><?php echo $row2['name']; ?></option>
          <?php
}
} ?>
          </select>
	</div></td>
	<td width="18%" height="30" align="left" valign="top" class="style5"><div align="center">Opening Dr <br />
        <input name="openingdr" type="text" id="openingdr" value="<?php echo $row['openingdr']; ?>" />
	</div></td>
    <td height="29" align="left" valign="top"><div align="center" class="style5">
      <div align="center" class="style5">Opening Cr <br />
        <input name="openingcr" type="text" id="openingcr" value="<?php echo $row['openingcr']; ?>" />
    </div></td>
    
     <td align="left"><input name="save" type="submit" class="style4" value="Save - This  account"></td>
  </tr>
</table>
</body>
</html>