<?php 
require("connection.php");
//$sql = "SELECT * FROM purchasereturn";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM purchasereturn WHERE invoiceno='$invoiceno'";
$sql2 = "SELECT * FROM purchasereturn WHERE invoiceno='$invoiceno'";
}
$result2 = $con->query($sql);

$result = $con->query($sql);


  // output data of each row
$row2 = $result2->fetch_assoc();
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style5 {
	font-weight: bold;
	font-size: x-large;
	color: #FFFFFF;
}
.style6 {
	color: #FFFFFF;
	font-weight: bold;
}
.style7 {
	color: #0000FF;
	font-weight: bold;
}
.style8 {color: #0000FF}
.style10 {color: #FF0000}
.style11 {font-weight: bold}
-->

</style>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

                
              <div align="center">
                                      <button class="printghaib style10  style11" onClick="window.print()"> 
                                      <div align="justify">Print</div>
                                      </button>
</div>
              <div align="center"></div><div align="center">
  <table width="45%" border="0">
    <tr>
      <td width="90%" bordercolor="#CCCCCC" bgcolor="#FF0000"><div align="center" class="style5">PURCHASE RETURN </div></td>
    </tr>
  </table>
  <table width="93%" border="0">
    <tr>
      <td width="35%" align="left"><div align="right" class="style7">Name:</div></td>
      <td width="11%"><span class="style7">
        <?php  echo $row2 ['supplieraccountname']; ?>
      </span></td>
      <td width="2%"><span class="style8"></span></td>
      <td width="1%"><span class="style8"></span></td>
       <td width="16%" align="right"><span class="style8"><strong>Date:</strong></span></td>
      <td width="35%"><span class="style8"><strong>
        <?php echo $row2['date']; ?>
      </strong>    &nbsp;</span></td>
    </tr>
    <tr>
      <td align="left"><div align="right" class="style8"><strong>Address:</strong></div></td>
      <td><span class="style8"><strong>
        <?php  echo $row2 ['address']; ?>
      </strong>&nbsp;&nbsp;</span></td>
      <td><span class="style8"></span></td>
      <td><span class="style8"></span></td>
      <td width="16%" align="right"><span class="style8"><strong>Invoice no:</strong> </span></td>
      <td><p align="left" class="style8"><strong>
          <?php echo $row2['invoiceno'];?>
    </strong></p>    </tr>
    </td>
  </table>
              </div>
  <tr>
    <td colspan="6">
      <div align="center">
        <table width="45%" border="2" bordercolor="#990000">
          <tr>
            
            <td width="31%"><div align="center"><span class="style7">Item</span></div></td>
          <td width="18%"><div align="center"><span class="style7">Rate</span></div></td>
          <td width="20%"><div align="center"><span class="style7">Quantity</span></div></td>
          <td width="31%"><div align="center"><span class="style7">Amount</span></div></td>
        </tr>
          <?php
if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <tr>
            <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['itemname']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['sale']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['quantity']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['amount']; ?></span></div></td>
        </tr>
          <?php  
	  $total = $total+$row['amount'];
	  }
} else {
  echo "0 results";
}
 ?>
          <table width="550" class="table table-striped table-dark">
            <tr>
              <td width="190" height="10" bordercolor="#CCCCCC" bgcolor="#FF0000" ><div align="right" class="style6">TOTAL:</div></td>
            <td width="20" height="0" bordercolor="#CCCCCC" bgcolor="#FF00"><?php echo $total; ?></td>
          </tr>
          </table>
        </table>
      </div>
      <form>
        <div align="center">
          <input type="button" class="style10" value="Go back!" onClick="history.back()">
        </div>
      </form>
</body>
</html>
