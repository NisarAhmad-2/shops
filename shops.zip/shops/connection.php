<?php
$host = "localhost";
$dbuser = "root";
$dbname = "shops";
$dbpass = "";
$con = new mysqli($host, $dbuser, $dbpass, $dbname);
if($con->connect_error){
	die("connection failed: ". $con->connect_error);
}
error_reporting(E_ALL^E_NOTICE);
?>
