<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$address = $_POST['address'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$saleamount = $_POST['saleamount'];
	$purchaseamount = $_POST['purchaseamount'];
	$purchaserate = $_POST['purchaserate'];
	$margin = $_POST['margin'];
	$totalmargin = $_POST['totalmargin'];
$sql = "INSERT INTO saleinvoice (invoiceno,refrenceno,date,address,supplieraccountcode,supplieraccountname,itemcode,itemname,quantity,sale,saleamount,purchaseamount,purchaserate,margin,totalmargin)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountcode','$supplieraccountname','$itemcode','$itemname','$quantity','$sale','$saleamount','$purchaseamount','$purchaserate','$margin','$totalmargin')";
if ($con->query($sql) === TRUE) {
 
  header("location:saleinvoice.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>