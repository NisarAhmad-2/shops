<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style3 {color: #0000FF}
.style5 {color: #0000FF; font-weight: bold; }
-->
</style>
</head>
<body>
<form action="purchasereturnadd.php" method="post">
<table width="885"  border="0" class="printghaib">
<tr>
<?php
$table = "purchasereturn";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>

  <td width="19%" align="left" valign="top" ><div align="center"><strong><span class="style3">Invoice No <br>
        <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $code; ?>">
  </span></strong></div></td>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style3">Refrence No <br>
        <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $code; ?>">
      </span>
    </strong></div>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style3">Date<br>
        <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
      
      </span>
    </strong></div>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style3">address <br>
        <input name="address" type="text" id="address" size="15" value="<?php echo $address; ?>">
      </span>
    </strong></div>
    <td width="13%" align="left" valign="top"><div align="center"><strong><span class="style3">Supplier Account<br>
        <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
    </span></strong></div></td>
    <td width="5%" height="62" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993" border="0" class="printghaib">
    <tr>
      <td width="96%" height="53" align="center" valign="top"><div align="center" class="style5">ITEM<br/>
            <select name="item" class="searchabledropdown" id="item" onChange="getSRate();">
              <option value="">Select an Item </option>
              <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
                <option value="<?php echo $row['code']."|".$row['name']."|".$row['salerate']; ?>"><?php echo $row['name']; ?></option>
              <?php
}
} ?>
                </select>
      </div></td>
	<td width="1%" align="left" valign="top">&nbsp;</td>
      <td width="2%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="1%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>	
</table>
</table>
<form name="form1" method="post" action="">
  <table width="1091"  border="0" class="printghaib">
    <tr>
      <td width="29%" align="left" valign="top"><div align="center"><strong><span class="style3">Quantity<br>
          <input name="quantity" type="number" id="quantity" size="15"
		 onKeyUp="getAmount();" onBlur="getAmount();">
      </span></strong></div></td>
      <td width="17%" align="left" valign="top"><div align="center"><strong><span class="style3">sale<br>
          <input name="sale" type="number" id="sale" size="15">
      </span></strong></div></td>
      
		      <td width="24%" align="left" numbervalign="top"><div align="center"><strong><span class="style3">Amount<br>
              <input name="amount" type="" id="amount" size="15" readonly="readonly">
                      </span></strong></div></td>
	  <td width="7%" align="left" valign="bottom">
	    <div align="right">
	      <input name="save" type="submit" class="style1" id="save" value="Save" />
        </div></td>
      <td width="19%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="4%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
</form>
<form action="preturnprint.php" class="printghaib" method="get">
        <input name="search" type="text" class="style1" placeholder="Search">
        <button name="submit" type="submit" class="style1">Search</button>
</form>
<?php
	require("purchasereturndisplay.php");
	?>
	

 </table>	
<script>
function getAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var amount = qty*sale;
document.getElementById('amount').value = amount;
}
function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;
}
</script>	
</body>
</html>