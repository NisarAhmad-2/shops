<?php 
require("connection.php");
//$sql = "SELECT * FROM salereturn";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM salereturn WHERE invoiceno='$invoiceno'";
$sql2 = "SELECT * FROM salereturn WHERE invoiceno='$invoiceno'";
}
$result2 = $con->query($sql);

$result = $con->query($sql);


  // output data of each row
$row2 = $result2->fetch_assoc();
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style5 {
	font-weight: bold;
	font-size: x-large;
	color: #FFFFFF;
}
.style6 {
	color: #FFFFFF;
	font-weight: bold;
}
.style7 {
	color: #0000FF;
	font-weight: bold;
}
.style8 {
	color: #FF0000;
	font-weight: bold;
}
.style9 {color: #0000FF}
-->

</style>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

                                    <div align="center">
                                        <button class="printghaib style8" onClick="window.print()"> Print</button>
                                        <p>&nbsp;</p>
</div>
                                      <div align="center"></div>              <div align="center">
  <table width="39%" border="0">
    <tr>
      <td width="90%" bordercolor="#CCCCCC" bgcolor="#FF0000"><div align="center" class="style5">SALE RETURN </div></td>
    </tr>
  </table>
  <table width="53%" border="0">
    <tr>
      <td width="27%" align="left"><div align="right" class="style7">Name:</div></td>
      <td width="20%"><span class="style7">
        <?php  echo $row2 ['supplieraccountname']; ?>
      </span></td>
      <td width="1%">&nbsp;</td>
      <td width="1%">&nbsp;</td>
       <td width="25%" align="right"><span class="style7">Date:</span></td>
      <td width="26%"><span class="style7">
        <?php echo $row2['date']; ?>        &nbsp;</span></td>
    </tr>
    <tr>
      <td align="left"><div align="right" class="style7">Address:</div></td>
      <td><span class="style7">
        <?php  echo $row2 ['address']; ?>
      &nbsp;&nbsp;</span></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td width="25%" align="right"><span class="style7">Invoice no: </span></td>
      <td><p align="left" class="style7">
          <?php echo $row2['invoiceno'];?>
    </p>    </tr>
    </td>
  </table>
              </div>
  <tr>
    <td colspan="6">
      <div align="center">
        <table width="40%" border="2" bordercolor="#990000">
          <tr>
            
            <td width="31%"><div align="center"><strong><span class="style9">Item</span></strong></div></td>
          <td width="18%"><div align="center"><strong><span class="style9">Rate</span></strong></div></td>
          <td width="20%"><div align="center"><strong><span class="style9">Quantity</span></strong></div></td>
          <td width="31%"><div align="center"><strong><span class="style9">Amount</span></strong></div></td>
        </tr>
          <?php
if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <tr>
            <td class="table table-striped table-dark"><div align="center"><strong><span class="style9"><?php echo $row['itemname']; ?></span></strong></div></td>
          <td class="table table-striped table-dark"><div align="center"><strong><span class="style9"><?php echo $row['sale']; ?></span></strong></div></td>
          <td class="table table-striped table-dark"><div align="center"><strong><span class="style9"><?php echo $row['quantity']; ?></span></strong></div></td>
          <td class="table table-striped table-dark"><div align="center"><strong><span class="style9"><?php echo $row['amount']; ?></span></strong></div></td>
        </tr>
          <?php  
	  $total = $total+$row['amount'];
	  }
} else {
  echo "0 results";
}
 ?>
          <table width="470" class="table table-striped table-dark">
            <tr>
              <td width="190" height="10" bordercolor="#CCCCCC" bgcolor="#FF0000" ><div align="right" class="style6">TOTAL:</div></td>
            <td width="20" height="0" bordercolor="#CCCCCC" bgcolor="#FF00"><?php echo $total; ?></td>
          </tr>
          </table>
        </table>
        <p>&nbsp;</p>
      </div>
      <form>
        <div align="center">
          <input type="button" class="style8" value="Go back!" onClick="history.back()">
        </div>
      </form>
</body>
</html>
