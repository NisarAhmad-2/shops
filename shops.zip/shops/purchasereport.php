<?php 
require("connection.php");
require("menu.php");
if(isset($_POST['supplieraccount'])){
$acc = $_POST['supplieraccount'];
$accex = explode('|',$acc);
$ac_code = $accex[0];
$datefrom = $_POST['datefrom'];
$dateto= $_POST['dateto'];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>SHOPS</title>
    <style type="text/css">
<!--
.style4 {color: #0000FF; font-weight: bold; }
.style5 {color: #0000FF}
-->
    </style>
</head>
<body>
<form action="" method="post">
<table width="899"  border="0">
  <tr>
  <td width="18%" align="center" valign="top"><div align="center"><span class="style4"><strong>Supplier Account</span><span class="style1"><br/>
        <select name="supplieraccount" class="style4" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
    </span>
  </div>
  <td width="4%" align="center" valign="bottom"><div align="center"></div>
  <td width="21%" align="left" valign="top"><div align="center"><span class="style4">Date from <br>
    <input name="datefrom" type="date" id="datefrom"  value="<?php echo date("Y-m-d");?>">
    </span>
  </div>
  <td width="32%" height="52" align="left" valign="bottom"><div align="center"><span class="style4">Date to <br>
    <input name="dateto" type="date" id="dateto"  value="<?php echo date("Y-m-d");?>">
  </span></div></td>
    <td width="11%" height="52" align="left" valign="bottom"><div align="center">
      <input name="search" type="submit" id="search" value="search" />
</div></td>
  </tr>
</table>
<p>&nbsp;</p>
</form>
<div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156"><div align="center"><strong><span class="style6 style5">Invoiceno</span></strong></div></th>
        <th width="110"><div align="center"><strong><span class="style6 style5">Refrenceno</span></strong></div></th>
        <th width="151"><div align="center"><strong><span class="style6 style5">Date</span></strong></div></th>
        <th width="150"><div align="center"><strong><span class="style6 style5">Supplieraccountname</span></strong></div></th>
        <th width="98"><div align="center"><strong><span class="style6 style5">Itemname</span></strong></div></th>
        <th width="92"><div align="center"><strong><span class="style6 style5">Quantity</span></strong></div></th>
        <th width="94"><div align="center"><strong><span class="style6 style5">Purchase</span></strong></div></th>
        <th width="91"><div align="center"><strong><span class="style6 style5">Amount</span></strong></div></th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php 
if(!empty($_POST['supplieraccount'])){
$sql = "SELECT * FROM purchaseinvoice WHERE supplieraccountcode = '$ac_code'  ";
$result = $con->query($sql);
}
if(!empty($_POST['supplieraccount']) && !empty($_POST['datefrom']) && !empty($_POST['dateto'])){
$sql = "SELECT * FROM purchaseinvoice WHERE supplieraccountcode = '$ac_code'  AND date BETWEEN
'$datefrom' AND '$dateto'";
$result = $con->query($sql);
}

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['invoiceno']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['refrenceno']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['date']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['itemname']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['quantity']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['purchase']; ?></span></strong></div></td>
        <td><div align="center" class="style5"><strong><span class="style6"><?php echo $row['amount']; ?></span></strong></div></td>
        <td><a href="purchaseinvoicedisplay.php?action=del&id=<?php echo $row['id']; ?>" class="style4" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td><a href="editpurchaseinvoice.php?invoiceno=<?php echo $row['invoiceno']; ?>" class="style4"> Edit</a></td>
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
</div>
</body>
</html> 