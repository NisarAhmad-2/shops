<?php 
require("connection.php");
if(isset($_POST['save'])){

$id = $_POST['id'];
$code = $_POST['code'];
$name = $_POST['name'];
	
$sql = "UPDATE headsnames SET 
		name = '$name'
		WHERE id = '$id'";

if ($con->query($sql) === TRUE) {
header("location:heads.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$id = $_GET['id'];
$sql = "SELECT * FROM headsnames WHERE id = '$id'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>
<style type="text/css">
<!--
.style2 {
	color: #FF0000;
	font-weight: bold;
}
.style3 {color: #0000FF}
-->
</style>


<form action="?" method="post">
<center>
  <span class="style2">
<style>
<style>
      body {
       padding: 60px;
	   
      }
    </style>
HEADS NAMES  </span>
  <table width="28%" height="108" border="0">
  <tr>
    <td width="35%" class="style3 mytd"><strong> Code</strong></td>
    <td width="65%" align="left">
	  <span class="style3">
	<input type="hidden" name="id" id="id" value="<?php echo $row['id']; ?>" readonly="readonly">
	<input type="text" name="code" id="code" value="<?php echo $row['code']; ?>" readonly="readonly">
	  </span></td>
  </tr>
  <tr>
    <td class="style3 mytd"><strong>Heads Names</strong></td>
    <td align="left"><input name="name" type="text" class="style3" id="name" value="<?php echo $row['name']; ?>"></td>
  </tr>
  <tr>
    <td height="29">&nbsp;</td>
    <td align="left"><input name="save" type="submit" class="style2" value="Save - This  head"></td>
  </tr>
</table>
</center>
</body>
</html>