<?php 
require("connection.php");
require ("menu.php");
?>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-size: large;
}
.style2 {color: #0000FF}
-->
</style>

<div class="container">
  <table width="100%" >
    <tr>
      <th scope="col"><div align="center" class="style1">STOCK POSITION </div></th>
    </tr>
  </table>
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53"><div align="center"><strong><span class="style2">Code</span></strong></div></th>
        <th width="96"><div align="center"><strong><span class="style2">Name</span></strong></div></th>
		<th width="133"><div align="center"><strong><span class="style2">Purchaserate</span></strong></div></th>
		<th width="90"><div align="center"><strong><span class="style2">Salerate</span></strong></div></th>
		<th width="76"><div align="center"><strong><span class="style2">Margin</span></strong></div></th>
		<th width="58"><div align="center"><strong><span class="style2">Stock</span></strong></div></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()){ ?>
  	 <tr>
  
<td><div align="center"><strong><span class="style2"><?php echo $itemcode = $row['code']; 
$sql2 = "select sum(quantity) as qty from purchaseinvoice WHERE itemcode = '$itemcode'";
$result2 = $con->query($sql2);

if ($result2->num_rows > 0) { 
$rowp = $result2->fetch_assoc();
}
$purchase_qty = $rowp['qty'];

$sql3 = "select sum(quantity) as qty from saleinvoice WHERE itemcode = '$itemcode'";
$result3 = $con->query($sql3);

if ($result3->num_rows > 0) { 
$rows = $result3->fetch_assoc();
}
$sale_qty = $rows['qty'];
//$open = $row['stock'];
//$stock = $open+$purchase_qty-$sale_qty;
$sql4 = "select sum(quantity) as qty from purchasereturn WHERE itemcode = '$itemcode'";
$result4 = $con->query($sql4);

if ($result4->num_rows > 0) { 
$rowpr = $result4->fetch_assoc();
}
$purchase_return_qty = $rowpr['qty'];
$sql5 = "select sum(quantity) as qty from salereturn WHERE itemcode = '$itemcode'";
$result5 = $con->query($sql5);

if ($result5->num_rows > 0) { 
$rowsr = $result5->fetch_assoc();
}
$sale_return_qty = $rowsr['qty'];
$stock = $purchase_qty-$purchase_return_qty-$sale_qty+$sale_return_qty;

?></span></strong></div></td>
<td><div align="center"><strong><span class="style2"><?php echo $row['name']; ?></span></strong></div></td>
<td><div align="center"><strong><span class="style2"><?php echo $row['purchaserate']; ?></span></strong></div></td>
<td><div align="center"><strong><span class="style2"><?php echo $row['salerate']; ?></span></strong></div></td>
<td><div align="center"><strong><span class="style2"><?php echo $row['margin']; ?></span></strong></div></td>
<td><div align="center"><strong><span class="style2"><?php echo $stock; ?></span></strong></div></td>
      </tr>
 <?php 
$tquantity = $tquantity+$row4['quantity'];
$tpurchase = $tpurchase+$row4['purchase'];  
$i = $i+1;
}//while loop.
  }
 else {
  echo "0 results";
}
 ?>    
    </tbody>
		</table>
</div>
</div>
</body>
</html> 