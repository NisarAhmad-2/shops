<?php 
require("connection.php");
if(isset($_POST['save'])){
$invoiceno = $_GET['invoiceno'];
$refrenceno = $_POST['refrenceno'];
$date = $_POST['date'];
$address = $_POST['address'];
$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$purchaserate = $_POST['purchaserate'];
	$saleamount = $_POST['saleamount'];
	$purchaseamount = $_POST['purchaseamount'];
	$margin = $_POST['margin'];
$sql = "UPDATE saleinvoice SET 
		invoiceno = '$invoiceno',
		refrenceno = '$refrenceno',
		date = '$date',
		address = '$address',
		supplieraccountcode = '$supplieraccountcode',
		supplieraccountname = '$supplieraccountname',
		itemcode = '$itemcode',
		itemname = '$itemname',
		quantity = '$quantity',
		sale = '$sale',
		purchaserate = '$purchaserate',
		saleamount = '$saleamount',
		purchaseamount = '$purchaseamount',
		margin = '$margin'
		WHERE invoiceno = '$invoiceno'";
		

if ($con->query($sql) === TRUE) {
header("location:saleinvoicedisplay.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$invoiceno = $_GET['invoiceno'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno = '$invoiceno'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #0000FF}
.style4 {color: #0000FF; font-weight: bold; }
-->
</style>


<form action="?action=edit&invoiceno=<?php echo $invoiceno; ?>" method="post">
<table width="940"  border="0">
<td width="18%" align="left" valign="top"><div align="center"><strong><span class="style2">Invoice No <br>
        <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $row['invoiceno']; ?>"  readonly="readonly" />
  </span>
</strong></div>
<td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Refrence No <br>
  <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $row['refrenceno']; ?>" readonly="readonly" />
  </span>
</strong></div>
<td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Date<br>
  <input name="date" type="date" id="date"  value="<?php echo $row['date']; ?>">
  </span>
</strong></div>
<td width="18%" align="left" valign="top"><div align="center"><strong><span class="style2">Address<br>
  <input name="address" type="address" id="address"  value="<?php echo $row['address']; ?>">
  </span>
</strong></div>
<td width="22%" align="center" valign="top"><div align="center"><strong><span class="style2">Supplier Account<br/>
  <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
    <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2= $result->fetch_assoc()) { ?>
    <option value="<?php echo $row2['code']."|".$row2['name']; ?>" <?php if($row['supplieraccountcode']==$row2['code']) echo 'selected="selected"'; ?>>
      <?php if($row2['supplieraccountcode']==$row2['code']) echo " selected"; ?>
      <?php echo $row2['name']; ?></option>
    <?php
}
} ?>
  </select>
</span></strong></div></td>
    <td width="2%" align="left" valign="top">&nbsp;</td>
    <td width="2%" height="79" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993"  border="0">
    <tr>
      <td width="96%" height="53" align="center" valign="top"><div align="center">
        <div align="center"><span class="style4">ITEM<br/>
            <select name="item" class="searchabledropdown" id="item" onChange="getSRate(); getPRate();">
              <option value="">Select an Item </option>
              <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row3 = $result->fetch_assoc()) { ?>
     <option value="<?php echo $row3['code']."|".$row3['name']."|".$row3['salerate']."|".$row3['purchaserate']; ?>"<?php if($row3['code']==$row3['code']) echo 'selected="selected"'; ?>><?php echo $row3['name']; ?></option>
              <?php
}
} ?>
            </select>
      </span> </div></td>
	
    </tr>	
</table>
</table>
  <table width="1519"  border="0">
    <tr>
      <td width="6%" align="left" valign="top"><div align="center"><strong><span class="style2">Quantity<br>
        <input name="quantity" type="number" id="quantity" size="8"value = "<?php echo $row['quantity']; ?>"
		 onKeyUp="getSAmount(); getPAmount(); getmargin();" onBlur="getSAmount(); getPAmount(); getmargin();"> 
        </span>
      </strong></div>
      <td width="6%" align="left" valign="top"><div align="center"><strong><span class="style2">sale<br>
        <input name="sale" type="number" id="sale" value = "<?php echo $row['sale']; ?>"size="10">
      </span></strong></div></td>
      <td width="6%" align="left" valign="top"><div align="center"><strong><span class="style2">Purchase<br>
        <input name="purchaserate" type="number" id="purchaserate" value = "<?php echo $row['purchaserate']; ?>"size="8">
      </span></strong></div></td>
<td width="6%" align="left" valign="top"><div align="center"><strong><span class="style2">S Amount<br>
  <input name="saleamount" type="number" id="saleamount" size="8" value = "<?php echo $row['saleamount']; ?>"readonly="readonly">
</span></strong></div></td>
      <td width="6%" align="left" valign="top"><div align="center"><strong><span class="style2">P Amount<br>
        <input name="purchaseamount" type="number" id="purchaseamount" size="8" value = "<?php echo $row['purchaseamount']; ?>"readonly="readonly">
      </span></strong></div></td>
      
		      <td width="6%" align="left" valign="top"><div align="center"><strong><span class="style2">Margin<br>
              <input name="margin" type="" id="margin" size="8" value="<?php echo $row['margin']; ?>" readonly="readonly">
                      </span></strong></div></td>
	  <td width="5%" align="left" valign="bottom"><input name="save" type="submit" class="style1" id="save" value="Save" /></td>
      <td width="1%" height="79" align="left" valign="bottom">&nbsp;</td>
      <td width="19%" height="79" align="center" valign="top">&nbsp;</td>
    </tr>
</table>
  <script> function getSAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var samount = qty*sale;
document.getElementById('saleamount').value = samount;
}
function getmargin(){
var samount = document.getElementById('saleamount').value;
var pamount = document.getElementById('purchaseamount').value;
var margin = samount-pamount;
document.getElementById('margin').value = margin;
}

function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;

}
</script>    
<td width="5%" align="left" valign="bottom"></td>
<td width="5%" align="left" valign="bottom"></td>
<script>function getPAmount(){
var qty = document.getElementById('quantity').value;
var purchase = document.getElementById('purchase').value;
var pamount = qty*purchase;
document.getElementById('purchaseamount').value = pamount;
}

function getPRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var prate = itemsplited[3];
document.getElementById('purchaserate').value = prate;
}
    </script></td>

</body>
</html>