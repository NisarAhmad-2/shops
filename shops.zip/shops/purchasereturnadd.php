<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$address = $_POST['address'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$amount = $_POST['amount'];
$sql = "INSERT INTO purchasereturn (invoiceno,refrenceno,date,address,supplieraccountcode,supplieraccountname,itemcode,itemname,quantity,sale,amount)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountcode','$supplieraccountname','$itemcode','$itemname','$quantity','$sale','$amount')";
if ($con->query($sql) === TRUE) {
 
  header("location:purchasereturn.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>