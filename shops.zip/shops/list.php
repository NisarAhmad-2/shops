<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="right"><strong>Name:</strong></td>
    <td><strong>
    <?php  echo $row2 ['supplieraccountname']; ?>
    </strong>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
     <td align="right"><strong>Date:</strong></td>
    <td><strong>
    <?php echo $row2['date']; ?>
    </strong>    &nbsp;</td>
</tr>
  <tr>
    <td align="right"><strong>Address:</strong></td>
    <td><strong>
      <?php  echo $row2 ['address']; ?>
    </strong>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="Right"><strong>Invoice no:</strong></td>
    <td><p><strong>
      <?php  echo $row2 ['invoiceno']; ?>
    </strong></p>
    </tr>
      <tr>
        <td colspan="4"><table width="100%" border="1">
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
