<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>
<style type="text/css">
<!--
.style1 {font-weight: bold}
.style2 {font-size: large}
.style3 {font-size: x-large}
.style4 {color: #FF0000}
.style5 {color: #0000FF}
.style7 {color: #0000FF; font-weight: bold; }
-->
</style>
</head>
<body>

<div align="center" class="style2">
    <span class="style4">
    <style type="text/css">
<!--
.style3 {font-weight: bold}
-->
    </style>
    
    <button class="printghaib style1 style3" onClick="window.print()">  Print</button>
    </span>
    <p>&nbsp;</p>
</div>
<div class="container">
  <table width="1232" class="table table-bordered"  class="printghaib">
    <thead>
      <tr>
        <th width="94"><span class="style7">Code</span></th>
        <th width="208" class="style7">Name</th>
        <th width="182" class="style7">Address</th>
        <th width="161" class="style7">Contact</th>
        <th width="153" class="style7">headsname</th>
        <th width="125" class="style7">Total Debit </th>
        <th width="130" class="style7">Total Credit </th>
        <th width="143" class="style7">Total Balance </th>
      </tr>
<tbody>
<?php
$sql = "SELECT * FROM accountsnames";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td class="style7"><?php echo $supplieraccountcode = $row['code']; ?></td>
<td class="style7"><?php echo $row['name']; ?></td>
<td class="style7"><?php echo $row['address']; ?></td>
<td class="style7"><?php echo $row['contact']; ?></td>
<td class="style7"><?php echo $row['headsname']; ?></td>
<td class="style7"><?php
$sql2 = "SELECT sum(debit) as debit, sum(credit) as credit FROM accountsledger WHERE supplieraccountcode='$supplieraccountcode'";
$result2 = $con->query($sql2);

if ($result2->num_rows > 0) {}
$row2 = $result2->fetch_assoc();
 echo $row2['debit']; ?></td>
<td class="style7"><?php echo $row2['credit']; ?></td>
<td class="style7"><?php echo $row2['debit']-$row2['credit']; ?></td>
  </tr>
<?php 
$supplieraccountcode=$balance;
$tcredit = $tcredit+$row2['credit'];
$tdebit = $tdebit+$row2['debit']; 
$tbalance = $tdebit-$tcredit; 
$i = $i+1;
}//while loop.
  }
 else {
  echo "0 results";
}
 ?>     
</tbody>
   <div align="center">
    <table width="1148"  border="0" >
      <tr>
        <td width="71%" height="28" align="right" valign="top" class="style5"><strong>Debit=<?php echo $tdebit; ?> </strong></td>
        <td width="12%" align="right" valign="top" class="style5"><strong>Credit=<?php echo $tcredit; ?></strong></td>
		<td width="17%" align="right" valign="top" class="style5"><div align="center">
	    <strong>Balance=<?php echo $tbalance; ?></strong></td>
	  <td class="style5"></div>
		
      <td class="style5"></tr>
    </table>
</div>
</div>
</body>
</html> 