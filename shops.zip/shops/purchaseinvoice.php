<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
    <style type="text/css">
<!--
.style1 {color: #0000FF}
.style4 {color: #FF0000; font-weight: bold; }
.style6 {color: #0000FF; font-weight: bold; }
-->
    </style>
</head>
<body>
<form action="purchaseinvoiceadd.php" method="post">
<table width="1054"  border="0">
<tr>
<?php
$table = "purchaseinvoice";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>
  <td width="20%" align="left" valign="top"><div align="center"><span class="style1"><strong>Invoice No </strong></span><strong><span class="style1"><br>
        <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $code; ?>">
  </span></strong></div></td>
    <td width="20%" align="left" valign="top"><div align="center"><strong><span class="style1">Refrence No <br>
        <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $code; ?>">
      </span>
    </strong></div>
    <td width="20%" align="left" valign="top"><div align="center"><strong><span class="style1">Date<br>
        <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
      
      </span>
    </strong></div>
    <td width="18%" align="center" valign="top"><div align="center"><strong><span class="style1">Supplier Account<br/>
        <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
        <br>
    </span></strong></div></td>
    <td width="17%" align="left" valign="top"><div align="center"></div></td>
    <td width="10%" height="79" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="1154"  border="0">
    <tr>
      <td width="80%" height="53" align="center" valign="top"><div align="center"><span class="style6">ITEM<br/>
            <select name="item" class="searchabledropdown" id="item" onChange="getPRate();">
              <option value="">Select an Item </option>
              <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
                <option value="<?php echo $row['code']."|".$row['name']."|".$row['purchaserate']; ?>"><?php echo $row['name']; ?></option>
              <?php
}
} ?>
              </select>
      </span></div></td>
	<td width="22%" align="left" valign="top">&nbsp;</td>
      <td width="16%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="32%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>	
</table>
</table>
<form name="form1" method="post" action="">
  <table width="1332"  border="0">
    <tr>
      <td width="21%" align="left" valign="top"><div align="center"><strong><span class="style1">Quantity<br>
          <input name="quantity" type="number" id="quantity" size="15"
		 onKeyUp="getAmount();" onBlur="getAmount();">
      </span></strong></div></td>
      <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style1">Purchase<br>
          <input name="purchase" type="number" id="purchase" size="15">
      </span></strong></div></td>
      
		      <td width="16%" align="left" numbervalign="top"><div align="center"><strong><span class="style1">Amount<br>
              <input name="amount" type="" id="amount" size="15" readonly="readonly">
                      </span></strong></div></td>
	  <td width="12%" align="left" valign="bottom">
	    <div align="center">
	      <input name="save" type="submit" class="style4" id="save" value="Save" />
        </div></td>
      <td width="32%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="0%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
</form>
  </table>
  <form action="purchaseinvoiceprint.php" class="style4" method="get">
        <input name="search" type="text" class="style4" placeholder="Search">
        <button type="submit" name="submit">Search</button>
</form>
  <?php
	require("purchaseinvoicedisplay.php");
	?>
	
<script>
function getAmount(){
var qty = document.getElementById('quantity').value;
var purchase = document.getElementById('purchase').value;
var amount = qty*purchase;
document.getElementById('amount').value = amount;
}

function getPRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var prate = itemsplited[2];
document.getElementById('purchase').value = prate;
}
</script>	
</body>
</html>
