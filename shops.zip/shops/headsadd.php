<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$name = $_POST['name'];
$sql = "INSERT INTO headsnames ( code,name)
VALUES ( '$code','$name')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:heads.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>