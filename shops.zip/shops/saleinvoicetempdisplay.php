<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM saleinvoicetemp WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:saleinvoicetemp.php");
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


    $invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$address = $_POST['address'];
	$supplieraccountname = $_POST['supplieraccountname'];
	$itemname = $_POST['itemname'];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$saleamount = $_POST['saleamount'];
	$purchaseamount = $_POST['purchaseamount'];
	$purchaserate = $_POST['purchaserate'];
	$margin = $_POST['margin'];
	$totalmargin = $_POST['totalmargin'];
$sql = "INSERT INTO saleinvoicetemp (invoiceno,refrenceno,date,address,supplieraccountcode,supplieraccountname,itemcode,itemname,quantity,sale,saleamount,purchaseamount,purchaserate,margin,totalmargin)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountcode','$supplieraccountname','$itemcode','$itemname','$quantity','$sale','$saleamount','$purchaseamount','$purchaserate','$margin','$totalmargin')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<style type="text/css">
<!--
.style3 {font-weight: bold}
-->
</style>
  <div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156">Invoice No</th>
        <th width="151">Date</th>
		<th width="151">address</th>
        <th width="150">SupplierAccountName</th>
        <th width="98">Item Name</th>
        <th width="92">Quantity</th>
        <th width="94">Sale</th>
        <th width="91">Amount</th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM saleinvoicetemp";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoicetemp WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $row['invoiceno']; ?></td>
        <td><?php echo $row['date']; ?></td>
		<td><?php echo $row['address']; ?></td>
        <td><?php echo $row['supplieraccountname']; ?></td>
        <td><?php echo $row['itemname']; ?></td>
        <td><?php echo $row['quantity']; ?></td>
        <td><?php echo $row['sale']; ?></td>
        <td><?php echo $row['saleamount']; ?></td>
		<td><?php echo $row['purchaseamount']; ?></td>
		<td><?php echo $row['purchaserate']; ?></td>
		<td><?php echo $row['margin']; ?></td>
		<td><?php echo $row['totalmargin']; ?></td>
        <td><a href="saleinvoicetempdisplay.php?action=del&id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td><a href="editsaleinvoicetemp.php?invoiceno=<?php echo $row['invoiceno']; ?>"> Edit</a></td>
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
</div>
</body>
</html> 