<?php 
require("connection.php");
require("menu.php");

if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM saleinvoice WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
	
		
	}	//inner if
}//outer if
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style4 {
	color: #FF0000;
	font-weight: bold;
	font-size: x-large;
}
.style5 {
	color: #0000FF;
	font-size: 18;
	font-weight: bold;
}
.style6 {
	color: #FF0000;
	font-weight: bold;
}
.style9 {color: #0000FF}
.style10 {
	color: #00FF00;
	font-weight: bold;
}
-->
</style>

      <div class="container" align="center">
      <form>
		
	    
	      <div align="left">
		      <button type="button" class="style5" onclick="window.location.href='saleinvoicetemp.php'">Add New Sale Invoice </button>
        </div>
      </form>
	  </div>
		 <div class="container" align="center">
		<form name="form1" method="post" action="">
   <div align="center" class="style1 style4">SALE INVOICE   </div>
 </form>
 </div>
  <div class="container" align="left">
 <form action="print.php" class="printghaib" method="get">
        <input name="search" type="text" class="style6" placeholder="Search">
        <button type="submit" name="submit"><span class="style6">Search</span></button>
</form>
</div>
  <div class="container">
    <table width="1326" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="140"><div align="center"><strong><span class="style9">Invoice No</span></strong></div></th>
        <th width="134"><div align="center"><strong><span class="style9">Date</span></strong></div></th>
		<th width="136"><div align="center"><strong><span class="style9">address</span></strong></div></th>
        <th width="226"><div align="center"><strong><span class="style9">SupplierAccountName</span></strong></div></th>
        <th width="169"><div align="center"><strong><span class="style9">Item Name</span></strong></div></th>
        <th width="120"><div align="center"><strong><span class="style9">Quantity</span></strong></div></th>
        <th width="91"><div align="center"><strong><span class="style9">Sale</span></strong></div></th>
        <th width="154"><div align="center"><strong><span class="style9">Sale amount</span></strong></div></th>
		<th width="59"></th>
		<th width="53"></th>
      </tr>
    </thead> 	
  <tbody>
    <?php
$sql = "SELECT * FROM saleinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <tr>
      <td height="28"><div align="center"><strong><span class="style9"><?php echo $row['invoiceno']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style9"><?php echo $row['date']; ?></span></strong></div></td>
	  <td><div align="center"><strong><span class="style9"><?php echo $row['address']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style9"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style9"><?php echo $row['itemname']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style9"><?php echo $row['quantity']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style9"><?php echo $row['sale']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style9"><?php echo $row['saleamount']; ?></span></strong></div></td>
	
		
      <td><a href="saleinvoicedisplay.php?action=del&id=<?php echo $row['id']; ?>" class="style6" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
      <td><a href="editsaleinvoice.php?invoiceno=<?php echo $row['invoiceno']; ?>" class="style10"> Edit</a></td>
    </tr>
    <?php  
	  $total = $total+$row['saleamount'];
	  }
} else {
  echo "0 results";
}
 ?>
  </tbody>
    </table>
  </div>

<table width="1048" class="table table-bordered" id="nisar">
  <tr>
    <td width="846" height="28"><div align="right" class="style6">TOTAL</div></td>
    <td width="190"><span class="style6"><?php echo $total; ?></span></td>
  </tr>
  <thead>
  <tbody>
    <?php
$sql = "SELECT * FROM saleinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <?php  
	  $total = $total+$row['sleamount'];
	  }
} else {
  echo "0 results";
}
 ?>
  </tbody>
</table>
</thead>