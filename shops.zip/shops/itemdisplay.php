<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM itemnames WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


$code = $_POST['code'];
$name = $_POST['name'];
$purchaserate = $_POST['purchaserate'];
$salerate = $_POST['salerate'];
$margin = $_POST['margin'];
$stock = $_POST['stock'];
$sql = "INSERT INTO itemnames ( code,name,purchaserate,salerate,margin,stock)
VALUES ( '$code','$name','$purchaserate','$salerate','$margin','$stock')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<style type="text/css">
<!--
.style3 {color: #0000FF; font-weight: bold; }
.style4 {
	color: #FF0000;
	font-weight: bold;
}
.style5 {
	color: #00FF00;
	font-weight: bold;
}
-->
</style>

<div class="container">
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53"><div align="left"><span class="style3">Code</span></div></th>
        <th width="66"><div align="left"><span class="style3">name</span></div></th>
		<th width="80"><div align="left"><span class="style3">purchaserate</span></div></th>
		<th width="99"><div align="left"><span class="style3">salerate</span></div></th>
		<th width="97"><div align="left"><span class="style3">margin</span></div></th>
		<th width="58"><div align="left"><span class="style3">stock</span></div></th>
		<th width="58"></th>
		<th width="37"></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><div align="left"><span class="style3"><?php echo $row['code']; ?></span></div></td>
<td><div align="left"><span class="style3"><?php echo $row['name']; ?></span></div></td>
<td><div align="left"><span class="style3"><?php echo $row['purchaserate']; ?></span></div></td>
<td><div align="left"><span class="style3"><?php echo $row['salerate']; ?></span></div></td>
<td><div align="left"><span class="style3"><?php echo $row['margin']; ?></span></div></td>
<td><div align="left"><span class="style3"><?php echo $row['stock']; ?></span></div></td>
     <td><a href="?action=del&id=<?php echo $row['id']; ?>" class="style4" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
       <td><a href="edititem.php?id=<?php echo $row['id']; ?>" class="style5"> Edit</a></td>
      </tr>
  	 
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html> 