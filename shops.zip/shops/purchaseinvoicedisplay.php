<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM purchaseinvoice WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:purchaseinvoice.php");
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


    $invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$supplieraccountname = $_POST['supplieraccountname'];
	$itemname = $_POST['itemname'];
	$quantity = $_POST['quantity'];
	$purchase = $_POST['purchase'];
	$amount = $_POST['amount'];
$sql = "INSERT INTO purchaseinvoice (invoiceno,refrenceno,date,supplieraccountname,itemname,quantity,purchase,amount)
VALUES ('$invoiceno','$refrenceno','$date','$supplieraccountname','$itemname','$quantity','$purchase','$amount')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<style type="text/css">
<!--
.style2 {
	color: #FF0000;
	font-weight: bold;
}
.style6 {color: #0000FF}
.style7 {
	color: #00FF00;
	font-weight: bold;
}
-->
</style>

  <div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156"><div align="center"><strong><span class="style6">Invoiceno</span></strong></div></th>
        <th width="110"><div align="center"><strong><span class="style6">Refrenceno</span></strong></div></th>
        <th width="151"><div align="center"><strong><span class="style6">Date</span></strong></div></th>
        <th width="150"><div align="center"><strong><span class="style6">Supplieraccountname</span></strong></div></th>
        <th width="98"><div align="center"><strong><span class="style6">Itemname</span></strong></div></th>
        <th width="92"><div align="center"><strong><span class="style6">Quantity</span></strong></div></th>
        <th width="94"><div align="center"><strong><span class="style6">Purchase</span></strong></div></th>
        <th width="91"><div align="center"><strong><span class="style6">Amount</span></strong></div></th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM purchaseinvoice";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><div align="center"><strong><span class="style6"><?php echo $row['invoiceno']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['refrenceno']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['date']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['itemname']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['quantity']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['purchase']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['amount']; ?></span></strong></div></td>
        <td><a href="purchaseinvoicedisplay.php?action=del&id=<?php echo $row['id']; ?>" class="style2" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td><a href="editpurchaseinvoice.php?invoiceno=<?php echo $row['invoiceno']; ?>" class="style7"> Edit</a></td>
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
</div>
</body>
</html> 