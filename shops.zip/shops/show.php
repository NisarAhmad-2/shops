<?php 
require("connection.php");
if(isset($_GET['invoiceno'])){
	if($_GET['action'] == "del"){
		$invoiceno = $_GET['invoiceno'];
		$sql = "DELETE FROM saleinvoice WHERE invoiceno='$invoiceno'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:saleinvoice.php");
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


    $invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$supplieraccountname = $_POST['supplieraccountname'];
	$itemname = $_POST['itemname'];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$amount = $_POST['amount'];
$sql = "INSERT INTO saleinvoice (invoiceno,refrenceno,date,supplieraccountname,itemname,quantity,sale,amount)
VALUES ('$invoiceno','$refrenceno','$date','$supplieraccountname','$itemname','$quantity','$sale','$amount')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
  <div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="90">Invoice No</th>
        <th width="90">Date</th>
        <th width="226">SupplierAccountName</th>
        <th width="90">Item Name</th>
        <th width="90">Quantity</th>
        <th width="90">Sale</th>
        <th width="90">Amount</th>
		
      </tr>
    </thead>
    <tbody>
      <?php
	  $invoiceno = $_GET['invoiceno'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
if(isset($_GET['invoiceno'])){
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $row['invoiceno']; ?>
        <td><?php echo $row['date']; ?></td>
        <td><?php echo $row['supplieraccountname']; ?></td>
        <td><?php echo $row['itemname']; ?></td>
        <td><?php echo $row['quantity']; ?></td>
        <td><?php echo $row['sale']; ?></td>
        <td><?php echo $row['amount']; ?></td>
        <td width="100"><a href="show.php?action=del&invoiceno=<?php echo $row['invoiceno']; ?>" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td width="294"><a href="editsaleinvoice.php?invoiceno=<?php echo $row['invoiceno']; ?>"> Edit</a></td>
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
