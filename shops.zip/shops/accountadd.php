<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$voucherno = $_POST['voucherno'];
	$date = $_POST['date'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$headsname = $_POST['headsname'];
	$headsname = explode('|',$headsname);
	$headscode = $headsname[0];
	$headsname = $headsname[1];
	$debit=$openingdr = $_POST['openingdr'];
	$credit=$openingcr = $_POST['openingcr'];
	$remarks=$_POST['remarks'];
	$entrytype=$_POST['entrytype'];
$sql = "INSERT INTO accountsnames ( code,voucherno,date,name,address,contact,headscode,headsname,openingdr,openingcr)
VALUES ( '$code','$voucherno','$date','$name','$address','$contact','$headscode','$headsname','$openingdr','$openingcr')";

if ($con->query($sql) === TRUE) {
  
  //header("location:account.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
$sql = "INSERT INTO accountsledger ( voucherno,date,supplieraccountcode,supplieraccountname,headscode,headsname,debit,credit,remarks,entrytype)
VALUES ( '$voucherno','$date','$code','$name','$headscode','$headsname','$debit','$credit','$remarks','$entrytype')";
if ($con->query($sql) === TRUE) {
		header("location:account.php");
		} else {
		  echo "Error: " . $sql . "<br>" . $con->error;
		}
		
		
	}	
?>