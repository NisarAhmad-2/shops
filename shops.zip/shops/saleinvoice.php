<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
	font-size: x-large;
}
.style2 {
	color: #0000FF;
	font-weight: bold;
}
.style3 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
</head>
<body>
<form action="?" method="post">
<table width="885"  border="0" class="printghaib">
<tr>
<?php
$table = "saleinvoice";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>

  <td width="19%" height="53" align="left" valign="top" ><div align="center"><span class="style2">Invoice No <br>
      <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $code; ?>">
  </span></div></td>
    
  </tr>
</table>
 <form name="form1" method="post" action="">
   <div align="center" class="style1">SALE INVOICE   </div>
 </form>
 <form action="print.php" class="printghaib" method="get">
        <input name="search" type="text" class="style1" placeholder="Search">
        <button type="submit" name="submit"><span class="style3">Search</span></button>
</form>
<?php
	require("saleinvoicedisplay.php");
	?>
	

 </table>	
<td width="5%" align="left" valign="bottom"><script>function getSAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var samount = qty*sale;
document.getElementById('saleamount').value = samount;
}
function getmargin(){
var samount = document.getElementById('saleamount').value;
var pamount = document.getElementById('purchaseamount').value;
var margin = samount-pamount;
document.getElementById('margin').value = margin;
}

function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;

}
    </script></td>
<td width="5%" align="left" valign="bottom"><script>function getPAmount(){
var qty = document.getElementById('quantity').value;
var purchase = document.getElementById('purchase').value;
var pamount = qty*purchase;
document.getElementById('purchaseamount').value = pamount;
}

function getPRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var prate = itemsplited[3];
document.getElementById('purchase').value = prate;
}
    </script></td>
</body>
</html>