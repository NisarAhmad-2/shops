<?php 
require("connection.php");
$supplieraccountcode = $_GET['suppliercode'];
$sql = "SELECT * FROM accountsledger WHERE supplieraccountcode = '$supplieraccountcode'";
$result = $con->query($sql);
 // output data of each row
$row = $result->fetch_assoc();
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style3 {
	font-weight: bold;
	color: #FF0000;
}
.style5 {
	font-weight: bold;
	font-size: x-large;
	color: #FFFFFF;
}
.style8 {font-size: large}
.style9 {
	color: #0000FF;
	font-weight: bold;
}
.style10 {color: #0000FF}
.style11 {font-weight: bold}
-->

</style>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
<title>Untitled Document</title>
</head>

<body>


  <div align="center">
      <button class="printghaib style3" onClick="window.print()"> Print</button>
</div>
  <div align="center"></div>
  <p>&nbsp;</p>
                                              <div align="center">
  <table width="76%" border="0">
    <tr>
      <td width="90%" bordercolor="#CCCCCC" bgcolor="#FF0000"><div align="center" class="style5"> LEDGER </div></td>
    </tr>
  </table>
  <table width="59%" border="0">
    <tr>
      <td width="57%" align="left"><div align="right" class="style9">Name:</div></td>
      <td width="43%"><span class="style9">
        <?php  echo $row ['supplieraccountname']; ?>
      </span></td>
    </tr>
  </table>
                                              </div>
                                              <tr>
    <td colspan="6">
      <div align="center">
  <table width="76%" border="2" bordercolor="#990000">
    <tr>
      <td width="16%"><div align="center" class="style9">Voucherno</div></td>
          <td width="10%"><div align="center" class="style9">Invoiceno</div></td>
	      <td width="13%"><span class="style9">Account Name</span></td>
          <td width="13%"><div align="center" class="style9">Date</div></td>
          <td width="11%"><div align="center" class="style9">Debit</div></td>
          <td width="11%"><div align="center" class="style9">Credit</div></td>
          <td width="13%"><div align="center" class="style9">Remarks</div></td>
          <td width="13%"><div align="center" class="style9">Entry Type</div></td>
        </tr>
    <?php
if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <tr>
      <td class="table table-striped table-dark"><div align="center" class="style9"><?php echo $row['voucherno']; ?></div></td>
          <td class="table table-striped table-dark style10 style11"><div align="center"><?php echo $row['invoiceno']; ?> </div>
            <div align="center"></div>
          <div align="center"></div></td>
	      <td class="table table-striped table-dark"> <div align="center" class="style9"><?php echo $row['supplieraccountname']; ?>
	      </div></td>
          <td class="table table-striped table-dark"><div align="center" class="style9"><?php echo $row['date']; ?></div></td>
          <td class="table table-striped table-dark"><div align="center" class="style9"><?php echo $row['debit']; ?></div></td>
          <td class="table table-striped table-dark"><div align="center" class="style9"><?php echo $row['credit']; ?></div></td>
          <td class="table table-striped table-dark"><div align="center" class="style9"><?php echo $row['remarks']; ?></div></td>
          <td class="table table-striped table-dark"><div align="center" class="style9"><?php echo $row['entrytype']; ?></div></td>
        </tr>
    <?php  
$supplieraccountcode=$balance;
$tcredit = $tcredit+$row['credit'];
$tdebit = $tdebit+$row['debit']; 
$tbalance = $tbalance+$row['balance']; 
$i = $i+1;
}//while loop.
  }
 else {
  echo "0 results";
}
 ?>
  </table>
  <table width="914" class="table table-striped table-dark">
    <tr>
      <td width="468" height="10"style="color: #ffffff; background-color: #ff0000"><div align="center" class="style8">
        <div align="right"></div>
              </div>
            <div align="right"></div><div align="center"></div></td>
          <td width="94"style="color: #ffffff; background-color: #ff0000"><div align="center"><?php echo $tdebit; ?> </div></td>
          <td width="94" height="10"style="color: #ffffff; background-color: #ff0000"><div align="center" class="style8"><?php echo $tcredit; ?></div>
          <div align="center"></div></td>
	      <td width="238" height="10" style="color: #ffffff; background-color: #ff0000"><div align="right" class="style8">
	          <div align="right"><span class="style8">Total =</span> <?php echo $tcredit-$tdebit; ?> </div>
            </span></div></td>
        </tr>
  </table>      
      </div>
      <p>&nbsp;</p>
      <form>
  <div align="center">
    <input type="button" class="style3" value="Go back!" onClick="history.back()">
  </div>
</form>

</body>
</html>
