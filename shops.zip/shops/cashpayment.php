<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$voucherno = $_POST['voucherno'];
	$date = $_POST['date'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$debit = $_POST['debit'];
	$remarks = $_POST['remarks'];
	$entrytype = $_POST['entrytype'];
$sql = "INSERT INTO accountsledger (voucherno,date,supplieraccountcode,supplieraccountname,debit,remarks,entrytype)
VALUES ('$voucherno','$date','$supplieraccountcode','$supplieraccountname','$debit','$remarks','$entrytype')";
if ($con->query($sql) === TRUE) {
  echo "<script>alert('data added');</script>";
  header("Location:cashpayment.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "INSERT INTO accountsledger (voucherno,date,supplieraccountname,debit,remarks,entrytype)
VALUES ('$voucherno','$date','$supplieraccountname','$debit','$remarks','$entrytype')";
		$sql = "DELETE FROM accountsledger WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:cashpayment.php");
		
	}	//inner if
}//outer if



require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>
<style type="text/css">
<!--
.style3 {color: #0000FF; font-weight: bold; }
.style4 {
	color: #FF0000;
	font-weight: bold;
}
.style5 {
	color: #00FF00;
	font-weight: bold;
}
.style6 {color: #0000FF}
-->
</style>
</head>
<body>
<form action="?action=save" method="post">
  <table width="1162"  border="0" class="printghaib">
<tr>
<?php
$table = "accountsledger";
$column = "voucherno";
include("maxvalue.php");
$code= $max;
 ?>

  <td width="20%" align="left" valign="top" ><div align="center"><span class="style3">Voucher No <br>
      <input name="voucherno" type="text" id="voucherno" size="15" value="<?php echo $code; ?>">
  </span></div></td>
    <td width="20%" align="left" valign="top"><div align="center"><span class="style3">Date<br>
        <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
      
      </span>
    </div>
    <td width="16%" align="left" valign="top"><div align="center"><span class="style3">Supplier Account<br>
        <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
      
      </span>
    </div>
    <td width="17%" align="left" valign="top"><div align="center"><span class="style3">Debit<br>
        <input name="debit" type="text" id="debit" size="15" value="<?php echo $debit; ?>">
    </span></div></td>
    
    <td width="13%" align="left" valign="top"><div align="center"><span class="style3">Remarks<br>
        <input name="remarks" type="text" id="remarks" size="15" value="<?php echo $remarks; ?>">
    </span></div></td>
    <td width="14%" height="61" align="center" valign="top"><div align="center"><span class="style3">Entry Type <br>
        <input name="entrytype" type="text" id="entrytype" size="10" value="cashpayment"readonly="readonly">
    </span></div></td>
  </tr>
</table>
  <div align="center">
    <input name="save" type="submit" class="style4" id="save" value="Save" />
  </div>
</form>
<span class="style6">
<style type="text/css">
<!--
.style3 {font-weight: bold}
-->
</style>
</span>
  <div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156"><span class="style3">Voucher No</span></th>
        <th width="151"><span class="style3">Date</span></th>
        <th width="150"><span class="style3">SupplierAccountName</span></th>
        <th width="94"><span class="style3">debit</span></th>
        <th width="91"><span class="style3">Remarks</span></th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM accountsledger where entrytype='cashpayment' group by voucherno";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM accountsledger WHERE voucherno='$voucherno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><span class="style3"><?php echo $row['voucherno']; ?></span></td>
        <td><span class="style3"><?php echo $row['date']; ?></span></td>
        <td><span class="style3"><?php echo $row['supplieraccountname']; ?></span></td>
        <td><span class="style3"><?php echo $row['debit']; ?></span></td>
        <td><span class="style3"><?php echo $row['remarks']; ?></span></td>
        <td><a href="?action=del&id=<?php echo $row['id']; ?>" class="style4" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td><a href="editcashpayment.php?voucherno=<?php echo $row['voucherno']; ?>" class="style5"> Edit</a></td>
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
</body>
</html>