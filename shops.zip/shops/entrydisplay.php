<?php 
require("connection.php");
if(isset($_GET['sno'])){
	if($_GET['action'] == "del"){
		$sno = $_GET['sno'];
		$sql = "DELETE FROM entry WHERE sno='$sno'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		
	}	//inner if
}//outer if

?>
<style type="text/css">
<!--
.style1 {color: #00FF00}
.style3 {color: #0000FF}
.style4 {
	color: #FF0000;
	font-weight: bold;
}
.style5 {color: #00FF00; font-weight: bold; }
.style6 {color: #666666}
-->
</style>

<div class="container">
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53"><span class="style3">Sno</span></th>
		<th width="53"><span class="style3">Date</span></th>
        <th width="66"><span class="style3">Name</span></th>
		<th width="53"><span class="style3">F Name</span></th>
		<th width="53"><span class="style3">CNIC</span></th>
		<th width="99"><span class="style3">Contact</span></th>
		<th width="81"><span class="style3">Address</span></th>
		
		<th width="63"><span class="style1"></span></th>
		<th width="41"><span class="style1"></span></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM entry";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><span class="style3"><?php echo $row['sno']; ?></span></td>
<td><span class="style3"><?php echo $row['date']; ?></span></td>
<td><span class="style3"><?php echo $row['name']; ?></span></td>
<td><span class="style3"><?php echo $row['fname']; ?></span></td>
<td><span class="style3"><?php echo $row['cnic']; ?></span></td>
<td><span class="style3"><?php echo $row['contact']; ?></span></td>
<td><span class="style3"><?php echo $row['address']; ?></span></td>

<td><a href="" class="style4" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
       <td><a href="editaccount.php?id=<?php echo $row['id']; ?>" class="style5 style6"> Edit</a></td>
      </tr>
  	 
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html> 