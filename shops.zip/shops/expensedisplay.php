<?php 
require("connection.php");

?>
<style type="text/css">
<!--
.style2 {
	color: #FF0000;
	font-weight: bold;
}
.style6 {color: #0000FF}
.style7 {
	color: #00FF00;
	font-weight: bold;
}
-->
</style>

  <div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156"><div align="center"><strong><span class="style6">voucherno</span></strong></div></th>
        <th width="218"><div align="center"><span class="style4">Supplieraccountname</span></div></th>
        <th width="151"><div align="center"><strong><span class="style6">Date</span></strong></div></th>
        <th width="150"><div align="center"><strong><span class="style6">debit</span></strong></div></th>
        <th width="98"><div align="center"><strong><span class="style6">remarks</span></strong></div></th>
       </div></th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM accountsnames";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><div align="center"><strong><span class="style6"><?php echo $row['voucherno']; ?></span></strong></div></td>
       <td><div align="center"><strong><span class="style6"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['date']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['debit']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['remarks']; ?></span></strong></div></td>
       
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
</div>
</body>
</html> 