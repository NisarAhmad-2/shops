<!DOCTYPE html>
<html>
<?php
include 'connection.php';
session_start();
?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}


input[type=text], input[type=password] {
  width: 10%;
  padding: 5px 8px;
  margin: 3px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #f44336;
  color: blue;
  padding: 5px 8px;
  margin: 2px 0;
  border: none;
  cursor: pointer;
  width: 10%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 10px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 20px 0 6px 0;
}

img.avatar {
  width: 10%;
  border-radius: 50%;
   float: center;
  
}

.container {
  padding: 0px;
}

span.psw {
  float: center;
  padding-top: 5px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 30px) {
  span.psw {
     display: block;
     float: center;
  }
  .cancelbtn {
     width: 20%;
  }
}
.style1 {
	color: #FF00FF;
	font-weight: bold;
}
.style3 {
	color: #0000FF;
	font-weight: bold;
}
.style6 {
	font-weight: bold;
	font-size: large;
	color: #FFFFFF;
}
</style>
</head>
<body>

<h2 align="center" class="style1">Login Form</h2>

<form action="loginprocess.php" method="post">
  <div class="imgcontainer">
    <div align="center"><img src="img_avatar2.png" alt="Avatar" class="avatar">
    </div>
  </div>

  <div class="container">
    <label for="uname">
    <div align="center" class="style3">Username    </div>
    <div align="right">
      <div align="center">
      <input name="username" type="text" class="style1" id="uname" placeholder="Enter Username" required>
      <label for="psw">
      </div>
      <div align="center">
     <p class="style3">Password</p>
     <p>
       <input name="password" type="password" class="style1" id="psw" placeholder="Enter Password" required>
</p>
  </div>
  
    <div align="center">
      <button type="submit" class="style6">Login</button>
    <div align="center"></div>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1"></div>
</form>

</body>
</html>