<?php
require("connection.php");
    session_start();
    $message="";
$sql = "SELECT * FROM user WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
 $_SESSION["id"] = $row;
}	else { echo "Username / Password is Incorrect"; }

    if(isset($_SESSION["id"])) {
    header("Location:index.php");
    }
?>