<?php 
require("connection.php");
//$sql = "SELECT * FROM saleinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
$sql2 = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result2 = $con->query($sql);

$result = $con->query($sql);


  // output data of each row
$row2 = $result2->fetch_assoc();
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style3 {font-weight: bold}
.style5 {
	font-weight: bold;
	font-size: x-large;
	color: #FFFFFF;
}
.style6 {
	color: #FFFFFF;
	font-weight: bold;
}
-->

</style>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

                
              <div align="left">
                                      <button class="style3 printghaib" onClick="window.print()"> Print</button>
</div>
<table width="39%" border="0">
<tr>
    <td width="90%" bordercolor="#CCCCCC" bgcolor="#FF0000"><div align="center" class="style5">SALE INVOICE </div></td>
  </tr>
</table>
        <table width="59%" border="0">
<tr>
    <td width="1%" align="left"><strong>Name:</strong></td>
    <td width="15%"><strong>
    <?php  echo $row2 ['supplieraccountname']; ?>
    </strong>&nbsp;</td>
    <td width="2%">&nbsp;</td>
    <td width="2%">&nbsp;</td>
     <td width="25%" align="right"><strong>Date:</strong></td>
    <td width="42%"><strong>
    <?php echo $row2['date']; ?>
    </strong>    &nbsp;</td>
</tr>
  <tr>
    <td align="left"><strong>Address:</strong></td>
    <td><strong>
      <?php  echo $row2 ['address']; ?>
    </strong>&nbsp;&nbsp;</td>
    <td>&nbsp;</td>
	<td>&nbsp;</td>
    <td width="10%" align="right"><strong>Invoice no:</strong> </td>
    <td><p align="left"><strong>
      <?php echo $row2['invoiceno'];?>
    </strong></p>    </tr>
	</td>
</table>
      
  <tr>
    <td colspan="6">
    <table width="39%" border="2" bordercolor="#990000">
      <tr>
	 
        <td width="31%"><strong>Item</strong></td>
        <td width="18%"><strong>Rate</strong></td>
        <td width="20%"><strong>Quantity</strong></td>
        <td width="31%"><strong>Amount</strong></td>
      </tr>
      <?php
if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td class="table table-striped table-dark"><?php echo $row['itemname']; ?></td>
        <td class="table table-striped table-dark"><?php echo $row['sale']; ?></td>
        <td class="table table-striped table-dark"><?php echo $row['quantity']; ?></td>
        <td class="table table-striped table-dark"><?php echo $row['amount']; ?></td>
      </tr>
      <?php  
	  $total = $total+$row['amount'];
	  }
} else {
  echo "0 results";
}
 ?>
      <table width="470" class="table table-striped table-dark">
        <tr>
          <td width="190" height="10" bordercolor="#CCCCCC" bgcolor="#FF0000" ><div align="right" class="style6">TOTAL:</div></td>
          <td width="20" height="0" bordercolor="#CCCCCC" bgcolor="#FF00"><?php echo $total; ?></td>
        </tr>
      </table>
</table>
<form>
 <input type="button" class="printghaib" value="Go back!" onClick="history.back()">
</form>
</body>
</html>
