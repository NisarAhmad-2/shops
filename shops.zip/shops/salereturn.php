<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>
<style type="text/css">
<!--
.style1 {color: #0000FF}
.style3 {color: #0000FF; font-weight: bold; }
.style4 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
</head>
<body>
<form action="salereturnadd.php" method="post">
<table width="885"  border="0" class="printghaib">
<tr>
<?php
$table = "salereturn";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>

  <td width="19%" align="left" valign="top" ><div align="center"><strong><span class="style1">Invoice No <br>
      <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $code; ?>">
  </span></strong></div></td>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style1">Refrence No <br>
        <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $code; ?>">
      </span>
    </strong></div>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style1">Date<br>
        <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
      
      </span>
    </strong></div>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style1">address <br>
        <input name="address" type="text" id="address" size="15" value="<?php echo $address; ?>">
      </span>
    </strong></div>
    <td width="13%" align="left" valign="top"><div align="center"><strong><span class="style1">Supplier Account<br>
        <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
    </span></strong></div></td>
    <td width="5%" height="62" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993" border="0" class="printghaib">
    <tr>
      <td width="88%" height="53" align="center" valign="top"><span class="style3">ITEM<br/>
        <select name="item" class="searchabledropdown" id="item" onChange="getSRate();">
            <option value="">Select an Item </option>
          <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']."|".$row['salerate']; ?>"><?php echo $row['name']; ?></option>
          <?php
}
} ?>
          </select>
      </span></td>
	<td width="1%" align="left" valign="top">&nbsp;</td>
      <td width="1%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="10%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>	
</table>
</table>
<form name="form1" method="post" action="">
  <table width="1091"  border="0" class="printghaib">
    <tr>
      <td width="24%" align="left" valign="top"><div align="center"><strong><span class="style1">Quantity<br>
          <input name="quantity" type="number" id="quantity" size="15"
		 onKeyUp="getAmount();" onBlur="getAmount();">
      </span></strong></div></td>
      <td width="20%" align="left" valign="top"><div align="center" class="style3">
        <div align="center">sale<br>
          <input name="sale" type="number" id="sale" size="15">
          </div>
      </div></td>
      
		      <td width="20%" align="left" numbervalign="top"><div align="center"><strong><span class="style1">Amount<br>
              <input name="amount" type="" id="amount" size="15" readonly="readonly">
                      </span></strong></div></td>
	  <td width="13%" align="left" valign="bottom"><input name="save" type="submit" class="style4" id="save" value="Save" /></td>
      <td width="19%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="4%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
</form>
<form action="sreturnprint.php" class="printghaib" method="get">
        <input name="search" type="text" class="style4" placeholder="Search">
        <button type="submit" name="submit"><span class="style4">Search</span></button>
</form>
<?php
	require("salereturndisplay.php");
	?>
	

 </table>	
<script>
function getAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var amount = qty*sale;
document.getElementById('amount').value = amount;
}
function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;
}
</script>	
</body>
</html>