<?php 
require("connection.php");
if(isset($_POST['save'])){

$code = $_POST['code'];
$name = $_POST['name'];
$purchaserate = $_POST['purchaserate'];	
$salerate = $_POST['salerate'];	
$margin = $_POST['margin'];	
$stock = $_POST['stock'];	
$sql = "UPDATE itemnames SET 
		name = '$name',
		purchaserate= '$purchaserate',
		salerate= '$salerate',
		margin= '$margin',
		stock= '$stock'
		WHERE code = '$code'";

if ($con->query($sql) === TRUE) {
header("location:item.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$id = $_GET['id'];
$sql = "SELECT * FROM itemnames WHERE id = '$id'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>
<style type="text/css">
<!--
.style3 {color: #0000FF; font-weight: bold; }
.style4 {color: #FF0000}
.style5 {color: #0000FF}
-->
</style>
<form action="?" method="post">
<table width="95%" height="74" border="0">
<td width="14%" align="left" valign="top"><div align="center"><span class="style5">Code</span><span class="style3"><br>
        <input name="code" type="text" id="code" value="<?php echo $row['code']; ?>" size="4" readonly="readonly" />
  </span>
</div>
<td width="17%" align="left" valign="top"><div align="center"><span class="style3">Name<br>
    <input name="name" type="text" id="name" value="<?php echo $row['name']; ?>" size="8" />
  </span>
</div>
<td width="17%" height="70" align="left" valign="top"><div align="center"><span class="style3">Purchase rate<br>
   <input name="purchaserate" type="text" id="purchaserate" value="<?php echo $row['purchaserate']; ?>" size="4" />
  </span>
</div>
<td width="17%" height="70" align="left" valign="top"><div align="center"><span class="style3">Sale rate <br>
    <input name="salerate" type="text" id="salerate" value="<?php echo $row['salerate']; ?>" size="4" />
  </span>
</div>
<td width="15%" height="70" align="left" valign="top"><div align="center"><span class="style3">Margin<br>
    <input name="margin" type="text" id="margin" value="<?php echo $row['margin']; ?>" size="4"  />
  </span>
</div>
<td width="11%" height="70" align="left" valign="top"><div align="center"><span class="style3">Stock<br>
   <input name="stock" type="text" id="stock" value="<?php echo $row['stock']; ?>" size="4"  />
  
  </span>
</div>
<td width="9%" align="center" valign="bottom"><input name="save" type="submit" class="style4" value="Save" /></td>
  </tr>
</table>
</body>
</html>