<?php 
require("connection.php");
require("menu.php");
if(isset($_POST['supplieraccount'])){
$acc = $_POST['supplieraccount'];
$accex = explode('|',$acc);
$ac_code = $accex[0];
$datefrom = $_POST['datefrom'];
$dateto= $_POST['dateto'];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>SHOPS</title>
    <style type="text/css">
<!--
.style4 {color: #0000FF; font-weight: bold; }
-->
    </style>
</head>
<body>


<form action="" method="post">
<table width="899"  border="0">
  <tr>
  <td width="32%" align="left" valign="top"><div align="center"><span class="style4"> Account<br>
      <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
        <?php
$sql = "SELECT * FROM accountsnames WHERE headscode = 5";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" <?php if($row['code']==$ac_code) echo " selected "; ?>><?php echo $row['name']; ?></option>
        <?php
}
} ?>
        </select>
    </span>
  </div>
  <td width="4%" align="center" valign="bottom"><div align="center"></div>
  <td width="21%" align="left" valign="top"><div align="center"><span class="style4">Date from <br>
    <input name="datefrom" type="date" id="datefrom"  value="<?php echo date("Y-m-d");?>">
    </span>
  </div>
  <td width="32%" height="52" align="left" valign="bottom"><div align="center"><span class="style4">Date to <br>
    <input name="dateto" type="date" id="dateto"  value="<?php echo date("Y-m-d");?>">
  </span></div></td>
    <td width="11%" height="52" align="left" valign="bottom"><div align="center">
      <input name="search" type="submit" id="search" value="search" />
</div></td>
  </tr>
</table>
<p>&nbsp;</p>
</form>
<div class="container">
  <table width="868" class="table table-bordered" >
    <thead>
      <tr>
        <th width="189"><div align="center"><span class="style4">Voucher No</span></div></th>
		<th width="218"><div align="center"><span class="style4">Supplieraccountname</span></div></th>
        <th width="139"><div align="center"><span class="style4">Date</span></div></th>
        <th width="151"><div align="center"><span class="style4">payment</span></div></th>
        <th width="147"><div align="center"><span class="style4">Remarks</span></div></th>
      </tr>
    </thead>
    <tbody>
      <?php 
if(!empty($_POST['supplieraccount'])){
$sql = "SELECT * FROM accountsledger WHERE supplieraccountcode = '$ac_code'  ";
$result = $con->query($sql);
}
if(!empty($_POST['supplieraccount']) && !empty($_POST['datefrom']) && !empty($_POST['dateto'])){
$sql = "SELECT * FROM accountsledger WHERE supplieraccountcode = '$ac_code'  AND date BETWEEN
'$datefrom' AND '$dateto'";
$result = $con->query($sql);
}

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><div align="center"><strong><span class="style6"><?php echo $row['voucherno']; ?></span></strong></div></td>
    <td><div align="center"><strong><span class="style6"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['date']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['debit']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style6"><?php echo $row['remarks']; ?></span></strong></div></td>
       
      </tr> 
 </tbody>
 <?php
  // output data of each row
  }
  }
  

 ?>

    </tbody>
	
  </table>
</div>
</body>
</html>