<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>account and inventory</title>
    <style type="text/css">
<!--
.style1 {color: #0000FF}
.style2 {color: #FF0000}
.style4 {color: #FF0000; font-weight: bold; }
-->
    </style>
</head>
  <body>
  
<form action="headsadd.php" method="post">
<center>
 <span class="style4">HEADS NAMES</span>
<table width="28%" height="108" border="0">
  <tr>
    <td width="25%" class="style1 mytd"><strong> Code</strong></td>
    <td width="68%" align="left">
	  <span class="style2">
	<?php
$table = "headsnames";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
	<input type="text" name="code" id="code" value="<?php echo $code; ?>" readonly="readonly">
	  </span></td>
  </tr>
  <tr>
    <td class="style1 mytd"><strong>HeadsNames</strong></td>
    <td align="left"><input name="name" type="text" class="style2" id="name"></td>
  </tr>
  <tr>
    <td height="29"><div align="left"></div></td>
    <td align="left">
      
        <div align="left">
          <input name="save" type="submit" class="style2" value="Save - This Head">
          </div></td></tr>
</table>
</center>
</body>
	<?php
	require("headsdisplay.php");
	?>
</html>