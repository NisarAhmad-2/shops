
<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>SHOP</title>
    <style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #0000FF}
-->
    </style>
</head>
<body>
<form action="itemadd.php" method="post">
<span class="style1">ITEMS:</span>
<table width="98%"  border="0">
  <tr>
    <?php
$table = "itemnames";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
    <td width="13%" height="53" align="left" valign="top"><div align="center"><strong><span class="style2">Code<br>
        <input name="code" type="text" id="code" value="<?php echo $code; ?>" size="4" readonly="readonly">
    </span></strong></div></td>
    <td width="16%" align="left" valign="top"><div align="center"><strong><span class="style2">Name<br>
        <input name="name" type="text" id="name" size="10">
    </span></strong></div></td>
	<td width="21%" align="left" valign="top"><div align="center"><strong><span class="style2">Purchase rate<br>
        <input name="purchaserate" type="number" id="purchaserate" size="10">
    </span></strong></div></td>
	<td width="12%" height="53" align="left" valign="top"><div align="center"><strong><span class="style2">Sale rate <br>
        <input name="salerate" type="text" id="salerate" size="10">
    </span></strong></div></td>
	<td width="12%" height="53" align="left" valign="top"><div align="center"><strong><span class="style2">Margin<br>
        <input name="margin" type="text" id="margin" size="10">
    </span></strong></div></td>
	<td width="1%" height="53" align="left" valign="top"><div align="center"></div></td>
  <tr>
    <td height="29" align="left" valign="top">
    <td width="16%" height="29" align="left" valign="top">&nbsp;</td>
    <td height="29" align="left" valign="top">&nbsp;</td>
    <td height="29" align="center" valign="top">&nbsp;</td>
    <td height="29" align="left" valign="top">&nbsp;</td>
    <td height="29" align="left" valign="top">&nbsp;</td>
    <td width="25%" align="center" valign="bottom"><div align="left">
      <input name="save" type="submit" class="style1" value="Save -This Item Name" />
    </div></td>
  </tr>
</table>

	<p>
	  <?php
	require("itemdisplay.php");
	?>
</p>
	<p>&nbsp;    </p>
</body>

</html>