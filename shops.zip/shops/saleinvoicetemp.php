<?php 
require("connection.php");
if(isset($_GET['action']) && $_GET['action']=="add"){
if(isset($_POST['add']))
{
	$invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$address = $_POST['address'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$saleamount = $_POST['saleamount'];
	$purchaseamount = $_POST['purchaseamount'];
	$purchaserate = $_POST['purchaserate'];
	$margin = $_POST['margin'];
	$totalmargin = $_POST['totalmargin'];
$sql = "INSERT INTO saleinvoicetemp (invoiceno,refrenceno,date,address,supplieraccountcode,supplieraccountname,itemcode,itemname,quantity,sale,saleamount,purchaseamount,purchaserate,margin,totalmargin)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountcode','$supplieraccountname','$itemcode','$itemname','$quantity','$sale','$saleamount','$purchaseamount','$purchaserate','$margin','$totalmargin')";
if ($con->query($sql) === TRUE) {
 echo "<script>alert('data added');</script>";
 header("Location:saleinvoicetemp.php");
 }
} } 
if(isset($_GET['action']) & $_GET['action']=="saveall"){
if(isset($_POST['save'])){
	$sql = "SELECT * FROM saleinvoicetemp ";
	$result = $con->query($sql);
	while($row = $result->fetch_assoc()) {
	$invoiceno = $row['invoiceno'];
	$refrenceno = $row['refrenceno'];
	$date = $row['date'];
	$address = $row['address'];
	$supplieraccountcode = $row['supplieraccount'];
	$supplieraccountname = $row['supplieraccountname'];

	$itemcode = $row['itemcode'];
	$itemname = $row['itemname'];
	$quantity = $row['quantity'];
	$sale = $row['sale'];
	$saleamount = $row['saleamount'];
	$purchaseamount = $row['purchaseamount'];	
	$purchaserate = $row['purchaserate'];
	$margin = $row['margin'];
	$totalmargin = $row['totalmargin'];
	$sql = "INSERT INTO saleinvoice (invoiceno,refrenceno,date,address,supplieraccountcode,supplieraccountname,itemcode,itemname,quantity,sale,saleamount,purchaseamount,purchaserate,margin,totalmargin)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountcode','$supplieraccountname','$itemcode','$itemname','$quantity','$sale','$saleamount','$purchaseamount','$purchaserate','$margin','$totalmargin')";
if ($con->query($sql) === TRUE) { $msg = "one done"; }
}
$sql = "DELETE FROM saleinvoicetemp";
		if ($con->query($sql) === TRUE) {
		}
header("Location:saleinvoicedisplay.php");
}
}
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
    <style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #0000FF}
.style3 {color: #0000FF; font-weight: bold; }
.style4 {
	color: #00FF00;
	font-weight: bold;
}
-->
    </style>
</head>
<body>
<form action="?action=add" method="post">
<table width="885"  border="0">
<tr>
<?php
$table = "saleinvoice";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>

  <td width="19%" align="left" valign="top"><div align="center" class="style3">
    <div align="center">Invoice No <br>
      <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $code; ?>" readonly="readonly">
      </div>
  </div></td>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Refrence No <br>
        <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $code; ?>">
      </span>
    </strong></div>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Date<br>
        <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
      </span>
    </strong></div>
    <td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Address <br>
        <input name="address" type="text" id="address" size="15" value="<?php echo $address; ?>">
      </span>
    </strong></div>
    <td width="22%" align="center" valign="top"><div align="center"><strong><span class="style2">Supplier Account<br/>
        <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
        <br>
    </span></strong></div></td>
    <td width="11%" align="left" valign="top">&nbsp;</td>
    <td width="10%" height="62" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993"  border="0">
    <tr>
      <td width="80%" height="53" align="center" valign="top"><span class="style3">ITEM<br/>
        <select name="item" class="searchabledropdown" id="item" onChange="getSRate(); getPRate();">
          <option value="">Select an Item </option>
          <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']."|".$row['salerate']."|".$row['purchaserate']; ?>"><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>
      </span></td>
	
    </tr>	
</table>
</table>
  <table width="1157"  border="0">
    <tr>
      <td width="17%" align="left" valign="top"><div align="center"><span class="style3">Quantity</span><br>
          <input name="quantity" type="number" class="style2" id="quantity" onBlur="getSAmount(); getPAmount(); getmargin();"
		 onKeyUp="getSAmount(); getPAmount(); getmargin();" size="8">  
      </div></td>
		 
      <td width="17%" align="left" valign="top"><div align="center"><span class="style3">Sale</span><br>
          <input name="sale" type="number" class="style2" id="sale" size="10">
      </div></td>
      <td width="17%" align="left" valign="top"><div align="center"><span class="style3">Purchase</span><br>
          <input name="purchaserate" type="number" class="style2" id="purchase" size="10">
      </div></td>
		      <td width="11%" align="left" numbervalign="top"><div align="center"><span class="style3">S Amount</span><br>
                <input name="saleamount" type="" class="style2" id="saleamount" size="10" readonly="readonly">
      </div></td>
	  <td width="17%" align="left" numbervalign="top"><div align="center"><span class="style3">P Amount</span><br>
          <input name="purchaseamount" type="number" class="style2" id="purchaseamount" size="10" readonly="readonly">
      </div></td>
	  <td width="10%" align="left" valign="bottom"><div align="center"><span class="style3">Margin</span><br>
          <input name="margin" type="number" class="style2" id="margin" size="10" /> 
	    </div>
	  <td width="1%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="10%" height="53" align="center" valign="bottom">
        
      
          <input name="add" type="submit" class="style1" id="add" value="add" />
       
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
   <table width="1326" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="78"><div align="center"><strong><span class="style2">Invoice No</span></strong></div></th>
        <th width="144"><div align="center"><strong><span class="style2">Date</span></strong></div></th>
		<th width="184"><div align="center"><strong><span class="style2">Address</span></strong></div></th>
        <th width="235"><div align="center"><strong><span class="style2">SupplierAccountName</span></strong></div></th>
        <th width="140"><div align="center"><strong><span class="style2">Item Name</span></strong></div></th>
        <th width="138"><div align="center"><strong><span class="style2">Quantity</span></strong></div></th>
        <th width="84"><div align="center"><strong><span class="style2">Sale</span></strong></div></th>
        <th width="169"><div align="center"><strong><span class="style2">Sale amount</span></strong></div></th>
		<th width="58"></th>
		<th width="52"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM saleinvoicetemp";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><div align="center"><strong><span class="style2"><?php echo $row['invoiceno']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style2"><?php echo $row['date']; ?></span></strong></div></td>
		<td><div align="center"><strong><span class="style2"><?php echo $row['address']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style2"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style2"><?php echo $row['itemname']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style2"><?php echo $row['quantity']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style2"><?php echo $row['sale']; ?></span></strong></div></td>
        <td><div align="center"><strong><span class="style2"><?php echo $row['saleamount']; ?></span></strong></div></td>
		<td width="58"><div align="center"><a href="saleinvoicetempdisplay.php?action=del&id=<?php echo $row['id']; ?>" class="style1" onclick="return confirm('Are you sure to Delete');">Delete</a></div></td>
        <td width="52"><div align="center"><a href="editsaleinvoice.php?invoiceno=<?php echo $row['invoiceno']; ?>" class="style4"> Edit</a></div></td>
      </tr>
      <?php  }
}  	
 ?>
    </tbody>
</table>

	<table width="724"  border="0">
<form action="?action=saveall" method="post">
  <tr>
          
      <div align="center">
     
      <input name="save" type="submit" class="style1" id="save" value="save" />    
      </div>
	  <td height="2"></td>
  </tr>
  </form>
</table>

<td width="5%" align="left" valign="bottom"><script>function getSAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var samount = qty*sale;
document.getElementById('saleamount').value = samount;
}
function getmargin(){
var samount = document.getElementById('saleamount').value;
var pamount = document.getElementById('purchaseamount').value;
var margin = samount-pamount;
document.getElementById('margin').value = margin;
}

function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;

}
    </script></td>
<td width="5%" align="left" valign="bottom"><script>function getPAmount(){
var qty = document.getElementById('quantity').value;
var purchase = document.getElementById('purchase').value;
var pamount = qty*purchase;
document.getElementById('purchaseamount').value = pamount;
}

function getPRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var prate = itemsplited[3];
document.getElementById('purchase').value = prate;
}
    </script></td>

</body>
</html>