<?php 
require("connection.php");
if(isset($_POST['save'])){
$id = $_GET['id'];
$voucherno = $_GET['voucherno'];
$date = $_POST['date'];
$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
$debit = $_POST['debit'];
$remarks = $_POST['remarks'];
$entrytype = $_POST['entrytype'];
$sql = "UPDATE accountsledger SET 
		
		date = '$date',
		supplieraccountcode = '$supplieraccountcode',
		supplieraccountname = '$supplieraccountname',
		debit = '$debit',
		remarks = '$remarks',
		entrytype = '$entrytype'
		WHERE voucherno = '$voucherno'";

if ($con->query($sql) === TRUE) {
header("location:cashpayment.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$voucherno = $_GET['voucherno'];
$sql = "SELECT * FROM accountsledger WHERE voucherno = '$voucherno'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>
<style type="text/css">
<!--
.style1 {color: #0000FF}
.style2 {color: #FF0000}
-->
</style>


<form action="?voucherno=<?php echo $voucherno; ?>" method="post">
<table width="95%" height="112" border="0">
  <tr>
    <td width="17%" height="53" align="left" valign="top"><div align="center"><strong><span class="style2"><span class="style1">Voucherno</span><br>
        <input name="voucherno" type="text" id="voucherno"value="<?php echo $row['voucherno']; ?>" readonly="readonly">
    </span></strong></div></td>
	  <td width="14%" align="left" valign="top"><div align="center"><strong><span class="style1">Date<br>
        <input name="date" type="date" id="date"  value="<?php echo $row['date']; ?>">
	    </span>
	      </strong></div>
    <td width="16%" align="center" valign="top"><div align="center"><strong><span class="style1">Supplier Account<br/>
        <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
          <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2= $result->fetch_assoc()) { ?>
          <option value="<?php echo $row2['code']."|".$row2['name']; ?>" <?php if($row['supplieraccountcode']==$row2['code']) echo 'selected="selected"'; ?><?php if($row2['supplieraccountcode']==$row2['code']) echo " selected"; ?>><?php echo $row2['name']; ?></option>
          <?php
}
} ?>
        </select>
    </span></strong></div></td>
    <td width="18%" align="left" valign="top"><div align="center"><strong><span class="style1">Debit<br>
        <input name="debit" type="" id="debit" value="<?php echo $row['debit']; ?>" />
    </span></strong></div></td>
	<td width="18%" height="53" align="left" valign="top"><div align="center"><strong><span class="style1">remarks<br>
        <input name="remarks" type="text" id="remarks" value="<?php echo $row['remarks']; ?>">
    </span></strong></div></td>
	<td width="13%" height="53" align="center" valign="top"><div align="center"><strong><span class="style1">Entry Type <br>
        <input name="entrytype" type="text" id="entrytype" size="15" value="<?php echo $row['entrytype']; ?>">
    </span></strong></div></td>
	<td width="2%" height="53" align="left" valign="top"><div align="center"></div></td>
	<td width="2%" height="53" align="left" valign="top">&nbsp;</td>
  <tr>
    <td height="53" align="left" valign="top">
    <td width="14%" height="53" align="left" valign="top">&nbsp;</td>
    
     <td align="left"><div align="right" class="style2">
       <input type="submit" value="Save" name="save">
     </div></td>
  </tr>
</table>
</body>
</html>