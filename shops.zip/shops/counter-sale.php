<?php 
require("connection.php");
if(isset($_GET['action']) && $_GET['action']=="add"){
if(isset($_POST['add']))
{
	$invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$address = $_POST['address'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$amount = $_POST['amount'];
$sql = "INSERT INTO saleinvoicetemp (invoiceno,refrenceno,date,address,supplieraccountname,itemname,quantity,sale,amount)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountname','$itemname','$quantity','$sale','$amount')";
if ($con->query($sql) === TRUE) {
 echo "<script>alert('data added');</script>";
 }
} } 
if(isset($_GET['action']) & $_GET['action']=="saveall"){
if(isset($_POST['save'])){
	$sql = "SELECT * FROM saleinvoicetemp ";
	$result = $con->query($sql);
	while($row = $result->fetch_assoc()) {
	$invoiceno = $row['invoiceno'];
	$refrenceno = $row['refrenceno'];
	$date = $row['date'];
	$address = $_POST['address'];
	$supplieraccountcode = $row['supplieraccount'];
	$supplieraccountname = $row['supplieraccountname'];

	$itemcode = $row['itemcode'];
	$itemname = $row['itemname'];
	$quantity = $row['quantity'];
	$sale = $row['sale'];
	$amount = $row['amount'];	
	
	$sql = "INSERT INTO saleinvoice (invoiceno,refrenceno,date,address,supplieraccountname,itemname,quantity,sale,amount)
VALUES ('$invoiceno','$refrenceno','$date','$address','$supplieraccountname','$itemname','$quantity','$sale','$amount')";
if ($con->query($sql) === TRUE) { $msg = "one done"; }
}
$sql = "DELETE FROM saleinvoicetemp";
		if ($con->query($sql) === TRUE) {
		}
header("Location:saleinvoice.php");
}
}
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>Shops</title>
</head>
<body>
<form action="?action=add" method="post">
<table width="885"  border="0">
<tr>
<?php
$table = "saleinvoice";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>

  <td width="19%" align="left" valign="top">Invoice No <br>
    <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $code; ?>" readonly="readonly"></td>
    <td width="19%" align="left" valign="top">Refrence No <br>
      <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $code; ?>">
    <td width="19%" align="left" valign="top">Date<br>
      <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
  <td width="19%" align="left" valign="top">address <br>
    <input name="address" type="text" id="address" size="15" value="<?php echo $address; ?>">
  <td width="22%" align="center" valign="top">Supplier Account<br/>
      <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
        <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
        <?php
}
} ?>
      </select>
    <br></td>
    <td width="11%" align="left" valign="top">&nbsp;</td>
    <td width="10%" height="62" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993"  border="0">
    <tr>
      <td width="80%" height="53" align="center" valign="top">ITEM<br/>
        <select name="item" class="searchabledropdown" id="item" onChange="getSRate();">
		<option value="">Select an Item </option>
          <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row['code']."|".$row['name']."|".$row['salerate']; ?>"><?php echo $row['name']; ?></option>
          <?php
}
} ?>
      </select></td>
	<td width="22%" align="left" valign="top">&nbsp;</td>
      <td width="16%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="32%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>	
</table>
</table>
  <table width="1091"  border="0">
    <tr>
      <td width="15%" align="left" valign="top">Quantity<br>
        <input name="quantity" type="number" id="quantity" size="15"
		 onKeyUp="getAmount();" onBlur="getAmount();"></td>
      <td width="15%" align="left" valign="top">sale<br>
        <input name="sale" type="number" id="sale" size="15"></td>
      
		      <td width="15%" align="left" numbervalign="top">Amount<br>
                <input name="amount" type="" id="amount" size="15" readonly="readonly"></td>
	  <td width="5%" align="left" valign="bottom"><input name="add" type="submit" id="add" value="add" /></td>
      <td width="29%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="1%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
   <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156">Invoice No</th>
        <th width="151">Date</th>
		<th width="154">address</th>
        <th width="150">SupplierAccountName</th>
        <th width="98">Item Name</th>
        <th width="92">Quantity</th>
        <th width="94">Sale</th>
        <th width="91">Amount</th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM saleinvoicetemp";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $row['invoiceno']; ?></td>
        <td><?php echo $row['date']; ?></td>
		<td><?php echo $row['address']; ?></td>
        <td><?php echo $row['supplieraccountname']; ?></td>
        <td><?php echo $row['itemname']; ?></td>
        <td><?php echo $row['quantity']; ?></td>
        <td><?php echo $row['sale']; ?></td>
        <td><?php echo $row['amount']; ?></td>
        <td><a href="saleinvoicetempdisplay.php?action=del&id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td><a href="editsaleinvoicetemp.php?invoiceno=<?php echo $row['invoiceno']; ?>"> Edit</a></td>
      </tr>
      <?php  }
}  	
 ?>
    </tbody>
  </table>

	<table width="724"  border="0">
<form action="?action=saveall" method="post">
  <tr>
          
      <div align="center">
     
      <input name="save" type="submit" id="save" value="save" />    
      </div>
	  <td height="2"></td>
  </tr>
  </form>
</table>

<td width="5%" align="left" valign="bottom"><script>function getAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var amount = qty*sale;
document.getElementById('amount').value = amount;
}

function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;
}
    </script></td>

</body>
</html>