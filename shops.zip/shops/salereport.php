<?php 
require("connection.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>SHOPS</title>
</head>
<body>
<form action="?" method="post">
<table width="885"  border="0">
<tr>
<?php
$table = "saleinvoice";
$column = "invoiceno";
include("maxvalue.php");
$code= $max;
 ?>

<?php
	require("saleinvoicedisplay.php");
	?>
</body>

</html>