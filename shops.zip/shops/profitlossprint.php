<?php 
require("connection.php");
//$sql = "SELECT * FROM saleinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
$sql2 = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result2 = $con->query($sql);

$result = $con->query($sql);


  // output data of each row
$row2 = $result2->fetch_assoc();
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style3 {
	font-weight: bold;
	color: #FF0000;
}
.style5 {
	font-weight: bold;
	font-size: x-large;
	color: #FFFFFF;
}
.style6 {
	color: #FFFFFF;
	font-weight: bold;
}
.style7 {
	color: #0000FF;
	font-weight: bold;
}
.style8 {color: #0000FF}
-->

</style>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

                      <div align="center">
                                        <button class="style3 printghaib" onClick="window.print()">                                        Print</button>
</div>
                                      <div align="center"></div><div align="center">
  <table width="62%" border="0">
    <tr>
      <td width="90%" bordercolor="#CCCCCC" bgcolor="#FF0000"><div align="center" class="style5">PROFIT AND LOSS </div></td>
    </tr>
  </table>
  <table width="61%" border="0">
    <tr>
      <td width="13%" align="left"><div align="center" class="style7">Name:</div></td>
      <td width="17%"><span class="style7">
      <?php  echo $row2 ['supplieraccountname'];?> 
      </span></td>
      <td width="22%" align="right"><span class="style7">Invoice no: </span></td>
      <td width="4%"><p align="left" class="style7"> <?php echo $row2['invoiceno'];?> </p>
      <td width="25%" align="right"><span class="style7">Date:</span></td>
      <td width="19%"><span class="style8"><strong>
        <?php echo $row2['date']; ?>
      </strong>    &nbsp;</span></td>
    </tr>
    <tr>    </tr>
    </td>
  </table>
              </div>
  <tr>
    <td colspan="6">
      <div align="center">
        <table width="62%" border="2" bordercolor="#990000">
          <tr>
            
            <td width="16%"><div align="center"><span class="style8"><strong>Itename</strong></span></div></td>
          <td width="14%"><div align="center"><span class="style8"><strong>Quantity</strong></span></div></td>
          <td width="9%"><div align="center"><span class="style8"><strong>Sale</strong></span></div></td>
          <td width="13%"><div align="center"><span class="style8"><strong>Sale Amount</strong></span></div></td>
		  <td width="18%"><div align="center"><span class="style8"><strong>Purchase Rate</strong></span></div></td>
          <td width="18%"><div align="center"><span class="style8"><strong>Purchase Amount</strong></span></div></td>
          <td width="12%"><div align="center"><span class="style8"><strong>Margin</strong></span></div></td>
        </tr>
          <?php
if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <tr>
            <td class="table table-striped table-dark"><span class="style8"><?php echo $row['itemname']; ?></span></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['quantity']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['sale']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['saleamount']; ?></span></div></td>
		  <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['purchaserate']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['purchaseamount']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style8"><?php echo $row['margin']; ?></span></div></td>
        </tr>
          <?php  
	  $total = $total+$row['saleamount'];
	  }
} else {
  echo "0 results";
}
 ?>
          <table width="750" class="table table-striped table-dark">
            <tr>
              <td width="190" height="10" bordercolor="#CCCCCC" bgcolor="#FF0000" ><div align="center" class="style6">TOTAL SALE AMOUNT:</div></td>
            <td width="20" height="0" bordercolor="#CCCCCC" bgcolor="#FF00"><?php echo $total; ?></td>
          </tr>
          </table>
        </table>
      </div>
      <form>
        <p align="center">
          <input type="button" class="style3" value="Go back!" onClick="history.back()">
        </p>
      </form>
</body>
</html>
