<?php 
require("connection.php");
if(isset($_GET['code'])){
	if($_GET['action'] == "del"){
		$code = $_GET['code'];
		$sql = "DELETE FROM accountsnames WHERE code='$code'";
		if ($code > 3) {
		if ($con->query($sql) === TRUE) {
		}  
		} else {
		  echo "" . $conn->error;
		}
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){

$code = $_POST['code'];
$name = $_POST['name'];
$address = $_POST['address'];
$contact = $_POST['contact'];
$headsname = $_POST['headsname'];
$sql = "INSERT INTO accountsnames ( code,name,address,contact,headsname)
VALUES ( '$code','$name','$address','$contact','$headsname')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<style type="text/css">
<!--
.style1 {color: #00FF00}
.style3 {color: #0000FF}
.style4 {
	color: #FF0000;
	font-weight: bold;
}
.style5 {color: #00FF00; font-weight: bold; }
.style6 {color: #666666}
-->
</style>

<div class="container">
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53"><span class="style3">Code</span></th>
        <th width="66"><span class="style3">Name</span></th>
		<th width="80"><span class="style3">Address</span></th>
		<th width="99"><span class="style3">Contact</span></th>
		<th width="61"><span class="style3">headsname</span></th>
		<th width="58"><span class="style1"></span></th>
		<th width="37"><span class="style1"></span></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM accountsnames";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><span class="style3"><?php echo $row['code']; ?></span></td>
<td><span class="style3"><?php echo $row['name']; ?></span></td>
<td><span class="style3"><?php echo $row['address']; ?></span></td>
<td><span class="style3"><?php echo $row['contact']; ?></span></td>
<td><span class="style3"><?php echo $row['headsname']; ?></span></td>
<td><a href="?action=del&code=<?php echo $row['code']; ?>" class="style4" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
       <td><a href="editaccount.php?id=<?php echo $row['id']; ?>" class="style5 style6"> Edit</a></td>
      </tr>
  	 
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html> 