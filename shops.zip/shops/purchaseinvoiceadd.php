<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$invoiceno = $_POST['invoiceno'];
	$voucherno = $_POST['voucherno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$purchase = $_POST['purchase'];
	$entrytype =$purchaseinvoice = "purchaseinvoice";
	$credit= $amount = $_POST['amount'];
	$sql = "INSERT INTO purchaseinvoice (invoiceno,refrenceno,date,supplieraccountcode,supplieraccountname,itemcode,itemname,quantity,purchase,amount)
VALUES ('$invoiceno','$refrenceno','$date','$supplieraccountcode','$supplieraccountname','$itemcode','$itemname','$quantity','$purchase','$amount')";
if ($con->query($sql) === TRUE) {
 
  header("location:purchaseinvoice.php");
} 
$sql = "INSERT INTO accountsledger (invoiceno,voucherno,date,supplieraccountcode,supplieraccountname,credit,entrytype)
VALUES ('$invoiceno','$voucherno','$date','$supplieraccountcode','$supplieraccountname','$credit','$purchaseinvoice')";
if ($con->query($sql) === TRUE) {
 
  header("location:purchaseinvoice.php");
} 
}
?>
