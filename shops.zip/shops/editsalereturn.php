<?php 
require("connection.php");
if(isset($_POST['save'])){
$invoiceno = $_POST['invoiceno'];
$refrenceno = $_POST['refrenceno'];
$date = $_POST['date'];
$address = $_POST['address'];
$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$amount = $_POST['amount'];
	
$sql = "UPDATE salereturn SET 
		invoiceno = '$invoiceno',
		refrenceno = '$refrenceno',
		date = '$date',
		address = '$address',
		supplieraccountcode = '$supplieraccountcode',
		supplieraccountname = '$supplieraccountname',
		itemcode = '$itemcode',
		itemname = '$itemname',
		quantity = '$quantity',
		sale = '$sale',
		amount = '$amount'
		WHERE invoiceno = '$invoiceno'";
		

if ($con->query($sql) === TRUE) {
header("location:salereturn.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$invoiceno = $_GET['invoiceno'];
$sql = "SELECT * FROM salereturn WHERE invoiceno = '$invoiceno'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #0000FF}
.style3 {color: #0000FF; font-weight: bold; }
-->
</style>


<form action="?action=edit&invoiceno=<?php echo $invoiceno; ?>" method="post">
<table width="885"  border="0">
<td width="15%" align="left" valign="top"><div align="center" class="style3">
  <div align="center">Invoice No <br>
    <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $row['invoiceno']; ?>"  readonly="readonly" />
  </div>
</div>
<td width="15%" align="left" valign="top"><div align="center"><strong><span class="style2">Refrence No <br>
    <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $row['refrenceno']; ?>" readonly="readonly" />
  </span>
  </strong>
</div>
<td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Date<br>
    <input name="date" type="date" id="date"  value="<?php echo $row['date']; ?>">
  </span>
  </strong>
</div>
<td width="19%" align="left" valign="top"><div align="center"><strong><span class="style2">Address<br>
    <input name="address" type="address" id="address"  value="<?php echo $row['address']; ?>">
  </span>
  </strong>
</div>
<td width="23%" align="center" valign="top"><div align="center"><strong><span class="style2">Supplier Account<br/>
    <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
      <?php
$sql = "SELECT * FROM accountsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <option value="<?php echo $row['code']."|".$row['name']; ?>" <?php if($row['supplieraccountcode']==$row['code']) echo " selected"; ?>><?php echo $row['name']; ?></option>
        <?php
}
} ?>
    </select>
</span></strong></div></td>
    <td width="2%" align="left" valign="top">&nbsp;</td>
    <td width="7%" height="79" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993"  border="0">
    <tr>
      <td width="95%" height="53" align="center" valign="top"><div align="center"><span class="style3">ITEM<br/>
            <select name="item" class="searchabledropdown" id="item" onChange="getSRate();">
              <option value="">Select an Item </option>
              <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2 = $result->fetch_assoc()) { ?>
                <option value="<?php echo $row2['code']."|".$row2['name']."|".$row2['salerate']; ?>"><?php echo $row2['name']; ?></option>
              <?php
}
} ?>
              </select>
      </span></div></td>
	<td width="1%" align="left" valign="top">&nbsp;</td>
      <td width="2%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="2%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>	
</table>
</table>
<form name="form1" method="post" action="">
  <table width="800"  border="0">
    <tr>
      <td width="7%" align="left" valign="top"><div align="center"><strong><span class="style2">Quantity<br>
          <input name="quantity" type="number" id="quantity" size="15"value="<?php echo $row['quantity']; ?>"  
		 onKeyUp="getAmount();" onBlur="getAmount();">
      </span></strong></div></td>
      <td width="63%" align="left" valign="top"><div align="center"><strong><span class="style2">sale<br>
          <input name="sale" type="number" id="sale" size="15"value="<?php echo $row['sale']; ?>"</span></strong></div></td> 

      
		      <td width="12%" align="left" numbervalign="top"><div align="center"><strong><span class="style2">Amount<br>
               <input name="amount" type="" id="amount" size="15" value="<?php echo $row['amount']; ?>" readonly="readonly">
                      </span></strong></div></td>
	  <td width="7%" align="Right" valign="bottom"><input name="save" type="submit" class="style1" id="save" value="Save" /></td>
      <td width="11%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="0%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
</form>
  </table>
<script>
function getAmount(){
var qty = document.getElementById('quantity').value;
var sale = document.getElementById('sale').value;
var amount = qty*sale;
document.getElementById('amount').value = amount;
}

function getSRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var srate = itemsplited[2];
document.getElementById('sale').value = srate;
}
</script>
</body>
</html>