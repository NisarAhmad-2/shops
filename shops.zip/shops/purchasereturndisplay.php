<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM purchasereturn WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:purchasereturn.php");
		
	}	//inner if
}//outer if
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style4 {
	color: #FF0000;
	font-weight: bold;
}
.style5 {
	color: #00FF00;
	font-weight: bold;
}
.style8 {color: #0000FF}
-->
</style>

      <div class="container" align="center">
        
		
  <div class="container">
    <table width="1170" class="table table-bordered" id="nisar">
      <thead>
  <tr>
    <th width="175"><div align="center"><strong><span class="style8">Invoice No</span></strong></div></th>
    <th width="154"><div align="center"><strong><span class="style8">Date</span></strong></div></th>
	<th width="154"><div align="center"><strong><span class="style8">Address</span></strong></div></th>
    <th width="160"><div align="center"><strong><span class="style8">SupplierAccountName</span></strong></div></th>
    <th width="131"><div align="center"><strong><span class="style8">Item Name</span></strong></div></th>
    <th width="122"><div align="center"><strong><span class="style8">Quantity</span></strong></div></th>
    <th width="79"><div align="center"><strong><span class="style8">Sale</span></strong></div></th>
    <th width="105"><div align="center"><strong><span class="style8">Amount</span></strong></div></th>
    <th width="58"></th>
    <th width="37"></th>
  </tr> 	
  <tbody>
    <?php
$sql = "SELECT * FROM purchasereturn";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM purchasereturn WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <tr>
      <td height="28"><div align="center"><strong><span class="style8"><?php echo $row['invoiceno']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style8"><?php echo $row['date']; ?></span></strong></div></td>
	  <td><div align="center"><strong><span class="style8"><?php echo $row['address']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style8"><?php echo $row['supplieraccountname']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style8"><?php echo $row['itemname']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style8"><?php echo $row['quantity']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style8"><?php echo $row['sale']; ?></span></strong></div></td>
      <td><div align="center"><strong><span class="style8"><?php echo $row['amount']; ?></span></strong></div></td>
      <td><a href="purchasereturndisplay.php?action=del&id=<?php echo $row['id']; ?>" class="style4" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
      <td><a href="editpurchasereturn.php?invoiceno=<?php echo $row['invoiceno']; ?>" class="style5"> Edit</a></td>
    </tr>
    <?php  
	  $total = $total+$row['amount'];
	  }
} else {
  echo "0 results";
}
 ?>
  </tbody>
    </table>
  </div>

<table width="1048" class="table table-bordered" id="nisar">
  <tr>
    <td width="812" height="28"><div align="right" class="style4">TOTAL</div></td>
    <td width="224"><span class="style4"><?php echo $total; ?></span></td>
  </tr>
  <thead>
  <tbody>
    <?php
$sql = "SELECT * FROM purchasereturn";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM purchasereturn WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <?php  
	  $total = $total+$row['amount'];
	  }
} else {
  echo "0 results";
}
 ?>
  </tbody>
</table>
</thead>