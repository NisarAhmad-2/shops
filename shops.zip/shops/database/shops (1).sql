-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2023 at 07:12 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shops`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountsledger`
--

CREATE TABLE `accountsledger` (
  `id` int(11) NOT NULL,
  `voucherno` int(50) NOT NULL,
  `invoiceno` int(50) NOT NULL,
  `date` date NOT NULL,
  `supplieraccountcode` int(50) NOT NULL,
  `supplieraccountname` varchar(50) NOT NULL,
  `headscode` int(50) NOT NULL,
  `headsname` varchar(50) NOT NULL,
  `itemcode` int(50) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `debit` varchar(50) NOT NULL,
  `credit` varchar(50) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `entrytype` varchar(50) NOT NULL,
  `balance` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `margin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accountsledger`
--

INSERT INTO `accountsledger` (`id`, `voucherno`, `invoiceno`, `date`, `supplieraccountcode`, `supplieraccountname`, `headscode`, `headsname`, `itemcode`, `itemname`, `debit`, `credit`, `remarks`, `entrytype`, `balance`, `quantity`, `margin`) VALUES
(1, 1, 0, '2022-11-08', 1, 'Nisar', 1, 'Nisar', 0, '', '200', '100', '', '', '', '', ''),
(5, 0, 1, '2022-11-08', 0, '', 0, '', 0, '', '', '', '', 'purchaseinvoice', '', '', ''),
(6, 0, 1, '2022-11-08', 0, '', 0, '', 0, '', '', '', '', 'purchaseinvoice', '', '', ''),
(7, 2, 0, '2022-11-08', 1, 'Nisar', 1, 'Nisar', 0, '', '200', '100', '', '', '', '', ''),
(8, 0, 1, '2022-11-08', 0, '', 0, '', 0, '', '', '100', '', 'purchaseinvoice', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `accountsnames`
--

CREATE TABLE `accountsnames` (
  `id` int(11) NOT NULL,
  `voucherno` int(50) NOT NULL,
  `data` date NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `headscode` int(50) NOT NULL,
  `headsname` varchar(50) NOT NULL,
  `openingdr` varchar(50) NOT NULL,
  `openingcr` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `headsnames`
--

CREATE TABLE `headsnames` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `headsnames`
--

INSERT INTO `headsnames` (`id`, `code`, `name`) VALUES
(1, '1', 'Nisar'),
(2, '2', 'Adnan'),
(3, '3', 'Taimor Khan');

-- --------------------------------------------------------

--
-- Table structure for table `itemnames`
--

CREATE TABLE `itemnames` (
  `id` int(11) NOT NULL,
  `code` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `purchaserate` int(50) NOT NULL,
  `salerate` int(50) NOT NULL,
  `margin` varchar(50) NOT NULL,
  `stock` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itemnames`
--

INSERT INTO `itemnames` (`id`, `code`, `name`, `purchaserate`, `salerate`, `margin`, `stock`) VALUES
(1, 1, 'Nisar', 50, 100, '50', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchaseinvoice`
--

CREATE TABLE `purchaseinvoice` (
  `id` int(11) NOT NULL,
  `invoiceno` int(11) NOT NULL,
  `voucherno` int(11) NOT NULL,
  `refrenceno` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `supplieraccountcode` int(11) NOT NULL,
  `supplieraccountname` int(11) NOT NULL,
  `itemcode` int(11) NOT NULL,
  `itemname` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseinvoice`
--

INSERT INTO `purchaseinvoice` (`id`, `invoiceno`, `voucherno`, `refrenceno`, `date`, `supplieraccountcode`, `supplieraccountname`, `itemcode`, `itemname`, `quantity`, `purchase`, `amount`) VALUES
(1, 1, 0, 1, 2022, 0, 0, 1, 0, 2, 50, 100);

-- --------------------------------------------------------

--
-- Table structure for table `purchasereport`
--

CREATE TABLE `purchasereport` (
  `id` int(11) NOT NULL,
  `invoiceno` int(11) NOT NULL,
  `voucherno` int(50) NOT NULL,
  `refrenceno` int(50) NOT NULL,
  `date` date NOT NULL,
  `supplieraccountcode` int(50) NOT NULL,
  `supplieraccountname` varchar(50) NOT NULL,
  `itemcode` varchar(50) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `purchase` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchasereturn`
--

CREATE TABLE `purchasereturn` (
  `id` int(11) NOT NULL,
  `invoiceno` varchar(50) NOT NULL,
  `voucherno` varchar(50) NOT NULL,
  `refrenceno` int(50) NOT NULL,
  `date` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `supplieraccountcode` int(50) NOT NULL,
  `supplieraccountname` varchar(50) NOT NULL,
  `itemcode` int(50) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sale` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `saleinvoice`
--

CREATE TABLE `saleinvoice` (
  `id` int(11) NOT NULL,
  `invoiceno` int(50) NOT NULL,
  `voucherno` int(50) NOT NULL,
  `refrenceno` int(50) NOT NULL,
  `date` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `supplieraccountcode` int(50) NOT NULL,
  `supplieraccountname` varchar(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `sale` varchar(50) NOT NULL,
  `purchase` varchar(50) NOT NULL,
  `saleamount` varchar(50) NOT NULL,
  `purchaseamount` varchar(50) NOT NULL,
  `margin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `saleinvoicetemp`
--

CREATE TABLE `saleinvoicetemp` (
  `id` int(11) NOT NULL,
  `voucherno` int(50) NOT NULL,
  `invoiceno` int(50) NOT NULL,
  `refrenceno` int(50) NOT NULL,
  `date` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `supplieraccountcode` int(50) NOT NULL,
  `supplieraccountname` varchar(50) NOT NULL,
  `itemcode` int(50) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sale` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salereturn`
--

CREATE TABLE `salereturn` (
  `id` int(50) NOT NULL,
  `invoiceno` int(50) NOT NULL,
  `refrenceno` int(50) NOT NULL,
  `date` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `supplieraccountcode` int(50) NOT NULL,
  `supplieraccountname` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sale` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'nisar', 'nisar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountsledger`
--
ALTER TABLE `accountsledger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `accountsnames`
--
ALTER TABLE `accountsnames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `headsnames`
--
ALTER TABLE `headsnames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itemnames`
--
ALTER TABLE `itemnames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchaseinvoice`
--
ALTER TABLE `purchaseinvoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasereport`
--
ALTER TABLE `purchasereport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasereturn`
--
ALTER TABLE `purchasereturn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saleinvoice`
--
ALTER TABLE `saleinvoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saleinvoicetemp`
--
ALTER TABLE `saleinvoicetemp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salereturn`
--
ALTER TABLE `salereturn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountsledger`
--
ALTER TABLE `accountsledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `accountsnames`
--
ALTER TABLE `accountsnames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `headsnames`
--
ALTER TABLE `headsnames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `itemnames`
--
ALTER TABLE `itemnames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `purchaseinvoice`
--
ALTER TABLE `purchaseinvoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `purchasereport`
--
ALTER TABLE `purchasereport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchasereturn`
--
ALTER TABLE `purchasereturn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleinvoice`
--
ALTER TABLE `saleinvoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleinvoicetemp`
--
ALTER TABLE `saleinvoicetemp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salereturn`
--
ALTER TABLE `salereturn`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
