<?php 
require("connection.php");
require("menu.php");
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style6 {color: #0000FF; font-weight: bold; }
.style7 {color: #FF0000}
.style9 {color: #FF0000; font-weight: bold; }
-->
</style>
<form action="profitlossprint.php" class="printghaib" method="get">
        <input name="search" type="text" class="style7" placeholder="Search">
        <button type="submit" name="submit">Search</button>
</form>
      <div class="container" align="center">
        
		
  <div class="container">
    <table width="1170" class="table table-bordered" id="nisar">
      <thead>
  <tr>
     <th width="156"><span class="style6">invoiceno</span></th>
        <th width="151"><span class="style6">date</span></th>
        <th width="150"><span class="style6">supplieraccountname</span></th>
        <th width="98"><span class="style6">itemname</span></th>
        <th width="92"><span class="style6">quantity</span></th>
		 <th width="150"><span class="style6">sale</span></th>
        <th width="98"><span class="style6">saleamount</span></th>
        <th width="94"><span class="style6">purchaserate</span></th>
        <th width="94"><span class="style6">purchaseamount</span></th>
        <th width="91"><span class="style6">margin</span></th>
  </tr> 	
  <tbody>
    <?php
$sql = "SELECT * FROM saleinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <tr>
      <td><span class="style6"><?php echo $row['invoiceno']; ?></span></td>
        <td><span class="style6"><?php echo $row['date']; ?></span></td>
        <td><span class="style6"><?php echo $row['supplieraccountname']; ?></span></td>
        <td><span class="style6"><?php echo $row['itemname']; ?></span></td>
        <td><span class="style6"><?php echo $row['quantity']; ?></span></td>
        <td><span class="style6"><?php echo $row['sale']; ?></span></td>
        <td><span class="style6"><?php echo $row['saleamount']; ?></span></td>
       <td><span class="style6"><?php echo $row['purchaserate']; ?></span></td>
        <td><span class="style6"><?php echo $row['purchaseamount']; ?></span></td>
        <td><span class="style6"><?php echo $row['margin']; ?></span></td>
    </tr>
    <?php  
	  $saletotal = $saletotal+$row['saleamount'];
	  $purchasetotal = $purchasetotal+$row['purchaseamount'];
	  $margintotal = $margintotal+$row['margin'];
 }
} else {
  echo "0 results";
}
 ?>
  </tbody>
    </table>

  </div>

<table width="1319" height="32" class="table table-bordered" id="nisar">
  <tr>
    <td width="887" height="28"><div align="right" class="style9">TOTAL SALE AMOUNT</div></td> 
    <td width="93"><span class="style9"><?php echo $saletotal; ?></span></td>
    <td width="186" height="28"><div align="right" class="style9">TOTAL PURCHASE AMOUNT</div></td> 
    <td width="17"><span class="style9"><?php echo $purchasetotal; ?></span></td>
    <td width="91" height="28"><div align="right" class="style9">TOTAL MARGIN</div></td>
    <td width="17"><span class="style9"><?php echo $margintotal; ?></span></td>
  </tr>
  <thead>
  <tbody>
    <?php
$sql = "SELECT * FROM saleinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM saleinvoice WHERE invoiceno='$invoiceno'";
}
$result = $con->query($sql);

if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
    <?php  
	  $total = $total+$row['saleamount'];
	   $purchasetotal = $purchasetotal+$row['purchaseamount'];
	  $margintotal = $margintotal+$row['margin'];
	  }
} else {
  echo "0 results";
}
 ?>
  </tbody>
</table>
</thead>