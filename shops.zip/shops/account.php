<em></em><?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>Accounts Names</title>
    <style type="text/css">
<!--
.style2 {color: #FF0000}
.style3 {color: #0000FF}
-->
    </style>
</head>
<body>
<span class="style2"><strong>ACCOUNT:

</strong>
<form action="accountadd.php" method="post">
</span>
<table width="100%"  border="0">
  <tr>
    <?php
$table = "accountsnames";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
  <?php
$table = "accountsledger";
$column = "voucherno";
include("maxvalue.php");
$voucherno = $max;
 ?>
 
    <td width="12%" height="56" align="left" valign="top"><div align="center"><span class="style3"><strong>Code</strong><br>
              <input name="code" type="text" id="code" value="<?php echo $code; ?>" size="10" readonly="readonly">
    </span> </div>
    <td width="21%" height="56" align="left" valign="top"><div align="center"><span class="style3"><strong>Voucherno</strong><br>
              <input name="voucherno" type="text" id="voucherno" value="<?php echo $voucherno; ?>" size="10" readonly="readonly">
    </span> </div>
    <td width="19%" align="left" valign="top"><div align="center"><span class="style3"><strong>Date</strong><br>
              <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
    </span> </div>
    <td width="10%" align="left" valign="top"><div align="center"><span class="style3"><strong>Name</strong><br>
              <input name="name" type="text" id="name" size="10">
    </span></div></td>
    <td width="14%" height="56" align="left" valign="top"><div align="center"><span class="style3"><strong>Address</strong><br>
              <input name="address" type="text" id="address" size="10">
    </span></div></td>
    <td width="10%" height="56" align="left" valign="top"><div align="center"><span class="style3"><strong>Contact</strong><br>
              <input name="contact" type="text" id="contact" size="10">
    </span></div></td>
    <td width="13%" height="56" align="left" valign="top"><div align="center"><span class="style3"><strong>Heads Names </strong><br/>
              <select name="headsname">
                <?php
$sql = "SELECT * FROM headsnames ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
                <option value="<?php echo $row['code']."|".$row['name']; ?>"><?php echo $row['name']; ?></option>
                <?php
}
} ?>
              </select>
    </span></div></td>
    <td width="0%" height="56" align="left" valign="top"><div align="center"></div></td>
    <td width="0%" height="56" align="left" valign="top"><div align="center"></div></td>
    <td width="1%" align="left" valign="top">&nbsp;</td>
  <tr>
    <td height="52" align="left" valign="top"><div align="center"><span class="style3"><strong>Opening Dr </strong><br>
        <input name="openingdr" type="text" id="openingdr" size="10">
    </span> </div>
    <td width="21%" height="52" align="left" valign="top"><div align="center"><span class="style3"><strong>Opening Cr </strong><br>
        <input name="openingcr" type="text" id="openingcr" size="10">
    </span></div></td>
    <td align="center" valign="bottom">
      
      <div align="center">
        <input name="save" type="submit" class="style2" value="Save -This account" />
      </div></td>
  </tr>
</table>
<?php
	require("accountdisplay.php");
	?>
</body>

</html>