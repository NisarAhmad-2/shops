<?php 
require("connection.php");
//$sql = "SELECT * FROM purchaseinvoice";
if(isset($_GET['search'])){
$invoiceno = $_GET['search'];
$sql = "SELECT * FROM purchaseinvoice WHERE invoiceno='$invoiceno'";
$sql2 = "SELECT * FROM purchaseinvoice WHERE invoiceno='$invoiceno'";
}
$result2 = $con->query($sql);

$result = $con->query($sql);


  // output data of each row
$row2 = $result2->fetch_assoc();
?>
<style type="text/css" media="print">
.printghaib {
display:none;
}
</style>


<style type="text/css">
<!--
.style5 {
	font-weight: bold;
	font-size: x-large;
	color: #FFFFFF;
}
.style6 {
	color: #FFFFFF;
	font-weight: bold;
}
.style7 {
	color: #0000FF;
	font-weight: bold;
}
.style8 {
	color: #FF0000;
	font-weight: bold;
}
-->

</style>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

                
<div align="center" class="style8">
<button class="printghaib style8" onClick="window.print()"> 
                                      <div align="center">Print</div>
</button>
<p>&nbsp;</p>
</div>
<div align="center"></div>
<div align="center">
  <table width="47%" border="0">
    <tr>
      <td width="90%" bordercolor="#CCCCCC" bgcolor="#FF0000"><div align="center" class="style5">PURCHASE INVOICE </div></td>
    </tr>
  </table>
  <table width="76%" border="0">
    <tr>
      <td width="28%" height="28" align="left"><div align="right"><span class="style7">Name:</span></div></td>
<td width="15%"><span class="style7">
          <?php  echo $row2 ['supplieraccountname']; ?>
          </span></td>
        <td width="1%">&nbsp;</td>
      <td width="1%">&nbsp;</td>
       <td width="27%" align="right"><span class="style7">Date:</span></td>
    <td width="28%"><span class="style7">
              <?php echo $row2['date']; ?>      &nbsp;</span></td>
    </tr>
    <tr>
      <td align="left"><div align="right"><span class="style7">Address:</span></div></td>
        <td><span class="style7">
          <?php  echo $row2 ['address']; ?>
          &nbsp;&nbsp;</span></td>
        <td>&nbsp;</td>
      <td>&nbsp;</td>
        <td width="27%" align="right"><span class="style7">Invoice no: </span></td>
      <td><p align="left" class="style7">
          <?php echo $row2['invoiceno'];?>
          </p>    
      </tr>
    </td>
  </table>
</div>
<tr>
    <td colspan="6">
      <div align="center">
        <table width="47%" border="2" bordercolor="#990000">
          <tr>
            
            <td width="31%"><div align="center"><span class="style7">Item</span></div></td>
          <td width="18%"><div align="center"><span class="style7">Rate</span></div></td>
          <td width="20%"><div align="center"><span class="style7">Quantity</span></div></td>
          <td width="31%"><div align="center"><span class="style7">Amount</span></div></td>
        </tr>
          <?php
if ($result->num_rows > 0) { $total = 0;
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <tr>
            <td class="table table-striped table-dark"><div align="center"><span class="style7"><?php echo $row['itemname']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style7"><?php echo $row['sale']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style7"><?php echo $row['quantity']; ?></span></div></td>
          <td class="table table-striped table-dark"><div align="center"><span class="style7"><?php echo $row['amount']; ?></span></div></td>
        </tr>
          <?php  
	  $total = $total+$row['amount'];
	  }
} else {
  echo "0 results";
}
 ?>
          <table width="570" class="table table-striped table-dark">
            <tr>
              <td width="120" height="10" bordercolor="#CCCCCC" bgcolor="#FF0000" ><div align="right" class="style6">TOTAL:</div></td>
            <td width="20" height="0" bordercolor="#CCCCCC" bgcolor="#FF0000"><?php echo $total; ?></td>
          </tr>
            </table>
        </table>
      </div>
      <form>
  <div align="center">
    <input type="button" class="style8" value="Go back!" onClick="history.back()">
  </div>
</form>
</body>
</html>
