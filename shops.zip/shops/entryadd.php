<?php 
if(isset($_POST['save']))
{
	$sno = $_POST['sno'];
	$date = $_POST['date'];
	$name = $_POST['name'];
	$fname = $_POST['fname'];
	$cnic = $_POST['cnic'];
	$contact = $_POST['contact'];
	$address = $_POST['address'];
$sql = "INSERT INTO entry ( sno,date,name,fname,cnic,contact,address)
VALUES ( '$sno','$date','$name','$fname','cnic','contact','address')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:buttons.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>